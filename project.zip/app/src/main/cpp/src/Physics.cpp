#include "kyzn/Physics.h"
#include <cmath>
namespace kyzn {
static const float GRAVITY = -9.8f;

void stepPhysics(Scene& s, float dt) {
    for (auto& e : s.entities) {
        if (!e.dynamic) continue;

        e.velocity.y += GRAVITY * dt;
        e.t.pos.x += e.velocity.x * dt;
        e.t.pos.y += e.velocity.y * dt;
        e.t.pos.z += e.velocity.z * dt;

        Vec3 ha{ e.t.scale.x*0.5f, e.t.scale.y*0.5f, e.t.scale.z*0.5f };
        for (auto& o : s.entities) {
            if (&o == &e || !o.solid || o.dynamic) continue;
            Vec3 hb{ o.t.scale.x*0.5f, o.t.scale.y*0.5f, o.t.scale.z*0.5f };
            float dx = e.t.pos.x - o.t.pos.x;
            float dy = e.t.pos.y - o.t.pos.y;
            float dz = e.t.pos.z - o.t.pos.z;
            float ox = ha.x+hb.x - fabsf(dx);
            float oy = ha.y+hb.y - fabsf(dy);
            float oz = ha.z+hb.z - fabsf(dz);
            if (ox > 0 && oy > 0 && oz > 0) {
                if (ox < oy && ox < oz)      { e.t.pos.x += (dx>0? ox : -ox); e.velocity.x = 0; }
                else if (oy < oz)            { e.t.pos.y += (dy>0? oy : -oy); e.velocity.y = 0; }
                else                         { e.t.pos.z += (dz>0? oz : -oz); e.velocity.z = 0; }
            }
        }
    }
}
}
