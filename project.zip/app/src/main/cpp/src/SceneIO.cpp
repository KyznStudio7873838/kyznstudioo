#include "kyzn/SceneIO.h"
#include <fstream>
#include <sstream>
#include <vector>
namespace kyzn {

static std::vector<std::string> splitCh(const std::string& s, char c) {
    std::vector<std::string> out; std::stringstream ss(s); std::string tok;
    while (std::getline(ss, tok, c)) out.push_back(tok);
    return out;
}

bool saveScene(const Scene& scene, const std::string& path) {
    std::ofstream f(path);
    if (!f) return false;
    for (const Entity& e : scene.entities) {
        f << e.name << ';' << e.mesh << ';' << e.texture << ';'
          << e.t.pos.x << ',' << e.t.pos.y << ',' << e.t.pos.z << ';'
          << e.t.scale.x << ',' << e.t.scale.y << ',' << e.t.scale.z << ';'
          << e.t.rotZ << ';' << e.t.rotY << ';'
          << e.color.x << ',' << e.color.y << ',' << e.color.z << ';'
          << (e.dynamic ? 1 : 0) << ';' << (e.solid ? 1 : 0) << '\n';
    }
    return true;
}

bool loadScene(Scene& scene, const std::string& path) {
    std::ifstream f(path);
    if (!f) return false;
    std::vector<Entity> loaded;
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty()) continue;
        auto parts = splitCh(line, ';');
        if (parts.size() < 10) continue;
        Entity e;
        e.name = parts[0]; e.mesh = parts[1]; e.texture = parts[2];
        auto p = splitCh(parts[3], ','); if (p.size()==3) e.t.pos = {std::stof(p[0]),std::stof(p[1]),std::stof(p[2])};
        auto sc = splitCh(parts[4], ','); if (sc.size()==3) e.t.scale = {std::stof(sc[0]),std::stof(sc[1]),std::stof(sc[2])};
        e.t.rotZ = std::stof(parts[5]);
        e.t.rotY = std::stof(parts[6]);
        auto co = splitCh(parts[7], ','); if (co.size()==3) e.color = {std::stof(co[0]),std::stof(co[1]),std::stof(co[2])};
        e.dynamic = parts[8] == "1";
        e.solid = parts[9] == "1";
        loaded.push_back(e);
    }
    if (loaded.empty()) return false;
    scene.entities = std::move(loaded);
    return true;
}
}
