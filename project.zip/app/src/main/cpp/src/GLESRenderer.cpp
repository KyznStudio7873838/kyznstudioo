#include "kyzn/Renderer.h"
#include "kyzn/AssetManager.h"
#include "kyzn/Texture.h"
#include "kyzn/Mesh.h"
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/native_window.h>
#include <android/log.h>
#include <unordered_map>
#include <memory>
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "KyznStudio", __VA_ARGS__)

namespace kyzn {
static const char* VS = R"(#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec2 aUV;
uniform mat4 uMVP;
out vec2 vUV;
void main(){ gl_Position = uMVP * vec4(aPos,1.0); vUV = aUV; })";
static const char* FS = R"(#version 300 es
precision mediump float;
in vec2 vUV;
uniform vec3 uColor;
uniform sampler2D uTex;
out vec4 o;
void main(){ o = vec4(uColor,1.0) * texture(uTex, vUV); })";

static GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr); glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char b[512]; glGetShaderInfoLog(s, 512, nullptr, b); LOG("shader: %s", b); }
    return s;
}

struct GPUMesh { GLuint vbo = 0; int count = 0; GLenum mode = GL_TRIANGLES; };

class GLESRenderer : public Renderer {
public:
    void setAssetManager(AssetManager* am) override { assets_ = am; }

    bool init(ANativeWindow* win) override {
        dpy_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
        eglInitialize(dpy_, nullptr, nullptr);
        const EGLint cfgAttr[] = { EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
            EGL_RED_SIZE,8, EGL_GREEN_SIZE,8, EGL_BLUE_SIZE,8, EGL_DEPTH_SIZE,16, EGL_NONE };
        EGLConfig cfg; EGLint n;
        if (!eglChooseConfig(dpy_, cfgAttr, &cfg, 1, &n) || n < 1) return false;
        surf_ = eglCreateWindowSurface(dpy_, cfg, win, nullptr);
        const EGLint ctxAttr[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
        ctx_ = eglCreateContext(dpy_, cfg, EGL_NO_CONTEXT, ctxAttr);
        if (!eglMakeCurrent(dpy_, surf_, surf_, ctx_)) return false;

        prog_ = glCreateProgram();
        glAttachShader(prog_, compile(GL_VERTEX_SHADER, VS));
        glAttachShader(prog_, compile(GL_FRAGMENT_SHADER, FS));
        glLinkProgram(prog_);
        uMVP_ = glGetUniformLocation(prog_, "uMVP");
        uColor_ = glGetUniformLocation(prog_, "uColor");
        uTex_ = glGetUniformLocation(prog_, "uTex");

        uploadMesh("quad", makeQuad());
        uploadMesh("cube", makeCube());
        makeWhiteTexture();

        glEnable(GL_DEPTH_TEST);
        return true;
    }

    void render(const Scene& s) override {
        EGLint w, h;
        eglQuerySurface(dpy_, surf_, EGL_WIDTH, &w);
        eglQuerySurface(dpy_, surf_, EGL_HEIGHT, &h);
        glViewport(0, 0, w, h);
        glClearColor(0.08f, 0.09f, 0.12f, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        float aspect = float(w) / float(h);
        const Camera& c = s.camera;
        Mat4 proj = c.mode == CameraMode::Ortho2D
            ? Mat4::ortho(c.orthoHeight * aspect, c.orthoHeight, -100, 100)
            : Mat4::perspective(c.fov, aspect, c.nearZ, c.farZ);
        Mat4 view = Mat4::translate({-c.pos.x, -c.pos.y, c.mode == CameraMode::Ortho2D ? 0 : -c.pos.z});
        Mat4 vp = Mat4::mul(proj, view);

        glUseProgram(prog_);
        glUniform1i(uTex_, 0);
        glActiveTexture(GL_TEXTURE0);

        for (const Entity& e : s.entities) {
            auto it = meshes_.find(e.mesh);
            if (it == meshes_.end()) it = meshes_.find("cube");
            const GPUMesh& gm = it->second;

            Mat4 rot = Mat4::mul(Mat4::rotY(e.t.rotY), Mat4::rotZ(e.t.rotZ));
            Mat4 model = Mat4::mul(Mat4::translate(e.t.pos), Mat4::mul(rot, Mat4::scale(e.t.scale)));
            Mat4 mvp = Mat4::mul(vp, model);
            glUniformMatrix4fv(uMVP_, 1, GL_FALSE, mvp.m);
            glUniform3f(uColor_, e.color.x, e.color.y, e.color.z);
            glBindTexture(GL_TEXTURE_2D, getTexture(e.texture));

            glBindBuffer(GL_ARRAY_BUFFER, gm.vbo);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5*sizeof(float), (void*)0);
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5*sizeof(float), (void*)(3*sizeof(float)));
            glDrawArrays(gm.mode, 0, gm.count);
        }
        eglSwapBuffers(dpy_, surf_);
    }

    void shutdown() override {
        if (dpy_ == EGL_NO_DISPLAY) return;
        eglMakeCurrent(dpy_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (ctx_ != EGL_NO_CONTEXT) eglDestroyContext(dpy_, ctx_);
        if (surf_ != EGL_NO_SURFACE) eglDestroySurface(dpy_, surf_);
        eglTerminate(dpy_);
        dpy_ = EGL_NO_DISPLAY; ctx_ = EGL_NO_CONTEXT; surf_ = EGL_NO_SURFACE;
    }

private:
    void uploadMesh(const char* name, const Mesh& cpu) {
        GPUMesh gm;
        glGenBuffers(1, &gm.vbo);
        glBindBuffer(GL_ARRAY_BUFFER, gm.vbo);
        glBufferData(GL_ARRAY_BUFFER, cpu.vertices.size()*sizeof(float), cpu.vertices.data(), GL_STATIC_DRAW);
        gm.count = cpu.vertexCount;
        gm.mode = cpu.mode == DrawMode::TriangleStrip ? GL_TRIANGLE_STRIP : GL_TRIANGLES;
        meshes_[name] = gm;
    }

    void makeWhiteTexture() {
        uint8_t px[4] = {255,255,255,255};
        glGenTextures(1, &whiteTex_);
        glBindTexture(GL_TEXTURE_2D, whiteTex_);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    }

    GLuint getTexture(const std::string& name) {
        if (name.empty()) return whiteTex_;
        auto it = textures_.find(name);
        if (it != textures_.end()) return it->second;

        GLuint tex = whiteTex_;
        std::vector<uint8_t> raw; DecodedImage img;
        if (assets_ && assets_->readBinary("textures/" + name, raw) && decodeBMP(raw, img)) {
            glGenTextures(1, &tex);
            glBindTexture(GL_TEXTURE_2D, tex);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img.width, img.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img.rgba.data());
            glGenerateMipmap(GL_TEXTURE_2D);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        } else {
            LOG("texture gagal dimuat: %s", name.c_str());
        }
        textures_[name] = tex;
        return tex;
    }

    EGLDisplay dpy_ = EGL_NO_DISPLAY; EGLSurface surf_ = EGL_NO_SURFACE; EGLContext ctx_ = EGL_NO_CONTEXT;
    GLuint prog_ = 0; GLint uMVP_ = -1, uColor_ = -1, uTex_ = -1;
    GLuint whiteTex_ = 0;
    AssetManager* assets_ = nullptr;
    std::unordered_map<std::string, GPUMesh> meshes_;
    std::unordered_map<std::string, GLuint> textures_;
};

std::unique_ptr<Renderer> createGLESRenderer() { return std::make_unique<GLESRenderer>(); }
}
