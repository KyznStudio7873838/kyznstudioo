#include "kyzn/Renderer.h"
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/native_window.h>
#include <android/log.h>
#include <memory>
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "KyznStudio", __VA_ARGS__)

namespace kyzn {
static const char* VS = R"(#version 300 es
layout(location=0) in vec2 aPos;
uniform mat4 uMVP;
void main(){ gl_Position = uMVP * vec4(aPos,0.0,1.0); })";
static const char* FS = R"(#version 300 es
precision mediump float;
uniform vec3 uColor; out vec4 o;
void main(){ o = vec4(uColor,1.0); })";

static GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr); glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char b[512]; glGetShaderInfoLog(s, 512, nullptr, b); LOG("shader: %s", b); }
    return s;
}

class GLESRenderer : public Renderer {
public:
    bool init(ANativeWindow* win) override {
        dpy_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
        eglInitialize(dpy_, nullptr, nullptr);
        const EGLint cfgAttr[] = { EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
            EGL_RED_SIZE,8, EGL_GREEN_SIZE,8, EGL_BLUE_SIZE,8, EGL_DEPTH_SIZE,16, EGL_NONE };
        EGLConfig cfg; EGLint n;
        if (!eglChooseConfig(dpy_, cfgAttr, &cfg, 1, &n) || n < 1) return false;
        surf_ = eglCreateWindowSurface(dpy_, cfg, win, nullptr);
        const EGLint ctxAttr[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
        ctx_ = eglCreateContext(dpy_, cfg, EGL_NO_CONTEXT, ctxAttr);
        if (!eglMakeCurrent(dpy_, surf_, surf_, ctx_)) return false;

        prog_ = glCreateProgram();
        glAttachShader(prog_, compile(GL_VERTEX_SHADER, VS));
        glAttachShader(prog_, compile(GL_FRAGMENT_SHADER, FS));
        glLinkProgram(prog_);
        uMVP_ = glGetUniformLocation(prog_, "uMVP");
        uColor_ = glGetUniformLocation(prog_, "uColor");

        const float quad[] = { -.5f,-.5f, .5f,-.5f, -.5f,.5f, .5f,.5f };
        glGenBuffers(1, &vbo_);
        glBindBuffer(GL_ARRAY_BUFFER, vbo_);
        glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
        glEnable(GL_DEPTH_TEST);
        return true;
    }

    void render(const Scene& s) override {
        EGLint w, h;
        eglQuerySurface(dpy_, surf_, EGL_WIDTH, &w);
        eglQuerySurface(dpy_, surf_, EGL_HEIGHT, &h);
        glViewport(0, 0, w, h);
        glClearColor(0.08f, 0.09f, 0.12f, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        float aspect = float(w) / float(h);
        const Camera& c = s.camera;
        Mat4 proj = c.mode == CameraMode::Ortho2D
            ? Mat4::ortho(c.orthoHeight * aspect, c.orthoHeight, -100, 100)
            : Mat4::perspective(c.fov, aspect, c.nearZ, c.farZ);
        Mat4 view = Mat4::translate({-c.pos.x, -c.pos.y, c.mode == CameraMode::Ortho2D ? 0 : -c.pos.z});
        Mat4 vp = Mat4::mul(proj, view);

        glUseProgram(prog_);
        glBindBuffer(GL_ARRAY_BUFFER, vbo_);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, nullptr);
        for (const Entity& e : s.entities) {
            Mat4 model = Mat4::mul(Mat4::translate(e.t.pos),
                         Mat4::mul(Mat4::rotZ(e.t.rotZ), Mat4::scale(e.t.scale)));
            Mat4 mvp = Mat4::mul(vp, model);
            glUniformMatrix4fv(uMVP_, 1, GL_FALSE, mvp.m);
            glUniform3f(uColor_, e.color.x, e.color.y, e.color.z);
            glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        }
        eglSwapBuffers(dpy_, surf_);
    }

    void shutdown() override {
        if (dpy_ == EGL_NO_DISPLAY) return;
        eglMakeCurrent(dpy_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (ctx_ != EGL_NO_CONTEXT) eglDestroyContext(dpy_, ctx_);
        if (surf_ != EGL_NO_SURFACE) eglDestroySurface(dpy_, surf_);
        eglTerminate(dpy_);
        dpy_ = EGL_NO_DISPLAY; ctx_ = EGL_NO_CONTEXT; surf_ = EGL_NO_SURFACE;
    }
private:
    EGLDisplay dpy_ = EGL_NO_DISPLAY; EGLSurface surf_ = EGL_NO_SURFACE; EGLContext ctx_ = EGL_NO_CONTEXT;
    GLuint prog_ = 0, vbo_ = 0; GLint uMVP_ = -1, uColor_ = -1;
};

std::unique_ptr<Renderer> createGLESRenderer() { return std::make_unique<GLESRenderer>(); }
}
