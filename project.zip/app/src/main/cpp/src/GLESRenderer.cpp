#include "kyzn/Renderer.h"
#include "kyzn/AssetManager.h"
#include "kyzn/Texture.h"
#include "kyzn/Mesh.h"
#include "kyzn/Camera.h"
#include "kyzn/Text.h"
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/native_window.h>
#include <android/log.h>
#include <unordered_map>
#include <memory>
#include <cmath>
#include <cstring>
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "KyznStudio", __VA_ARGS__)

namespace kyzn {
static const char* VS = R"(#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
uniform mat4 uMVP;
uniform mat4 uModel;
out vec3 vNormal;
out vec2 vUV;
void main(){
    gl_Position = uMVP * vec4(aPos,1.0);
    vNormal = mat3(uModel) * aNormal;
    vUV = aUV;
})";
static const char* FS = R"(#version 300 es
precision mediump float;
in vec3 vNormal;
in vec2 vUV;
uniform vec3 uColor;
uniform sampler2D uTex;
uniform vec3 uLightDir;
uniform vec3 uLightColor;
uniform float uAmbient;
out vec4 o;
void main(){
    vec3 n = normalize(vNormal);
    float diff = max(dot(n, -uLightDir), 0.0);
    vec3 lit = uColor * (uAmbient + diff * uLightColor);
    o = vec4(lit, 1.0) * texture(uTex, vUV);
})";

static GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr); glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char b[512]; glGetShaderInfoLog(s, 512, nullptr, b); LOG("shader: %s", b); }
    return s;
}

struct GPUMesh { GLuint vbo = 0; int count = 0; GLenum mode = GL_TRIANGLES; };

class GLESRenderer : public Renderer {
public:
    void setAssetManager(AssetManager* am) override { assets_ = am; }

    bool init(ANativeWindow* win) override {
        dpy_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
        eglInitialize(dpy_, nullptr, nullptr);
        const EGLint cfgAttr[] = { EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
            EGL_RED_SIZE,8, EGL_GREEN_SIZE,8, EGL_BLUE_SIZE,8, EGL_DEPTH_SIZE,16, EGL_NONE };
        EGLConfig cfg; EGLint n;
        if (!eglChooseConfig(dpy_, cfgAttr, &cfg, 1, &n) || n < 1) return false;
        surf_ = eglCreateWindowSurface(dpy_, cfg, win, nullptr);
        const EGLint ctxAttr[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
        ctx_ = eglCreateContext(dpy_, cfg, EGL_NO_CONTEXT, ctxAttr);
        if (!eglMakeCurrent(dpy_, surf_, surf_, ctx_)) return false;

        prog_ = glCreateProgram();
        glAttachShader(prog_, compile(GL_VERTEX_SHADER, VS));
        glAttachShader(prog_, compile(GL_FRAGMENT_SHADER, FS));
        glLinkProgram(prog_);
        uMVP_ = glGetUniformLocation(prog_, "uMVP");
        uModel_ = glGetUniformLocation(prog_, "uModel");
        uColor_ = glGetUniformLocation(prog_, "uColor");
        uTex_ = glGetUniformLocation(prog_, "uTex");
        uLightDir_ = glGetUniformLocation(prog_, "uLightDir");
        uLightColor_ = glGetUniformLocation(prog_, "uLightColor");
        uAmbient_ = glGetUniformLocation(prog_, "uAmbient");

        uploadMesh("quad", makeQuad());
        uploadMesh("cube", makeCube());
        makeWhiteTexture();
        loadFontAtlas();
        glGenBuffers(1, &textVbo_);

        glEnable(GL_DEPTH_TEST);
        return true;
    }

    void render(Scene& s) override {
        EGLint w, h;
        eglQuerySurface(dpy_, surf_, EGL_WIDTH, &w);
        eglQuerySurface(dpy_, surf_, EGL_HEIGHT, &h);
        s.screenW = w; s.screenH = h;
        glViewport(0, 0, w, h);
        glClearColor(0.08f, 0.09f, 0.12f, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        float aspect = float(w) / float(h);
        Mat4 vp = buildViewProj(s.camera, aspect);

        glUseProgram(prog_);
        glUniform1i(uTex_, 0);
        glActiveTexture(GL_TEXTURE0);

        float lx = s.light.direction.x, ly = s.light.direction.y, lz = s.light.direction.z;
        float len = sqrtf(lx*lx + ly*ly + lz*lz); if (len < 1e-5f) len = 1;
        glUniform3f(uLightDir_, lx/len, ly/len, lz/len);
        glUniform3f(uLightColor_, s.light.color.x * s.light.intensity, s.light.color.y * s.light.intensity, s.light.color.z * s.light.intensity);
        glUniform1f(uAmbient_, s.light.ambient);

        for (size_t i = 0; i < s.entities.size(); i++) {
            const Entity& e = s.entities[i];
            auto it = meshes_.find(e.mesh);
            if (it == meshes_.end()) it = meshes_.find("cube");
            const GPUMesh& gm = it->second;

            Mat4 rot = Mat4::mul(Mat4::rotY(e.t.rotY), Mat4::rotZ(e.t.rotZ));
            Mat4 model = Mat4::mul(Mat4::translate(e.t.pos), Mat4::mul(rot, Mat4::scale(e.t.scale)));
            Mat4 mvp = Mat4::mul(vp, model);
            glUniformMatrix4fv(uMVP_, 1, GL_FALSE, mvp.m);
            glUniformMatrix4fv(uModel_, 1, GL_FALSE, model.m);

            Vec3 col = e.color;
            if ((int)i == s.selectedEntity) { col.x = fminf(col.x*1.6f+0.2f,1.f); col.y = fminf(col.y*1.6f+0.2f,1.f); col.z = fminf(col.z*1.6f+0.2f,1.f); }
            glUniform3f(uColor_, col.x, col.y, col.z);
            glBindTexture(GL_TEXTURE_2D, getTexture(e.texture));

            drawMesh(gm);
        }

        drawUI(s, w, h);
        eglSwapBuffers(dpy_, surf_);
    }

    void shutdown() override {
        if (dpy_ == EGL_NO_DISPLAY) return;
        eglMakeCurrent(dpy_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (ctx_ != EGL_NO_CONTEXT) eglDestroyContext(dpy_, ctx_);
        if (surf_ != EGL_NO_SURFACE) eglDestroySurface(dpy_, surf_);
        eglTerminate(dpy_);
        dpy_ = EGL_NO_DISPLAY; ctx_ = EGL_NO_CONTEXT; surf_ = EGL_NO_SURFACE;
    }

private:
    void drawMesh(const GPUMesh& gm) {
        glBindBuffer(GL_ARRAY_BUFFER, gm.vbo);
        const GLsizei stride = 8 * sizeof(float);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3*sizeof(float)));
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6*sizeof(float)));
        glDrawArrays(gm.mode, 0, gm.count);
    }

    // Kotak solid warna (panel/tombol), koordinat piksel layar.
    void drawUIQuad(float x, float y, float w, float h, Vec3 color, int screenW, int screenH) {
        Mat4 proj = Mat4::screenOrtho((float)screenW, (float)screenH);
        Mat4 model = Mat4::mul(Mat4::translate({x + w*0.5f, y + h*0.5f, 0}), Mat4::scale({w, h, 1}));
        Mat4 mvp = Mat4::mul(proj, model);
        glUniformMatrix4fv(uMVP_, 1, GL_FALSE, mvp.m);
        glUniformMatrix4fv(uModel_, 1, GL_FALSE, Mat4::identity().m);
        glUniform3f(uColor_, color.x, color.y, color.z);
        glBindTexture(GL_TEXTURE_2D, whiteTex_);
        drawMesh(meshes_["quad"]);
    }

    // Teks dari font bitmap 5x7, digambar additive (huruf putih menambah cahaya, latar tak berubah).
    void drawText(const std::string& text, float x, float y, float scale, Vec3 color, int screenW, int screenH) {
        if (text.empty()) return;
        std::vector<float> verts;
        verts.reserve(text.size() * 6 * 8);
        float cw = GLYPH_W * scale, ch = GLYPH_H * scale;
        float atlasW = (float)(FONT_COLS * FONT_CELL_W);
        int rows = (int)((strlen(FONT_CHARSET) + FONT_COLS - 1) / FONT_COLS);
        float atlasH = (float)(rows * FONT_CELL_H);
        float cursorX = x;
        for (char c : text) {
            int idx = glyphIndex(c);
            if (idx < 0) { cursorX += cw + scale; continue; }
            int col = idx % FONT_COLS, row = idx / FONT_COLS;
            float u0 = (col*FONT_CELL_W) / atlasW, v0 = (row*FONT_CELL_H) / atlasH;
            float u1 = (col*FONT_CELL_W + GLYPH_W) / atlasW, v1 = (row*FONT_CELL_H + GLYPH_H) / atlasH;
            float x0=cursorX, x1=cursorX+cw, y0=y, y1=y+ch;
            float quad[6][4] = {
                {x0,y0,u0,v0},{x1,y0,u1,v0},{x1,y1,u1,v1},
                {x0,y0,u0,v0},{x1,y1,u1,v1},{x0,y1,u0,v1}
            };
            for (auto& p : quad) {
                float vtx[8] = {p[0],p[1],0, 0,0,1, p[2],p[3]};
                verts.insert(verts.end(), vtx, vtx+8);
            }
            cursorX += cw + scale;
        }
        if (verts.empty()) return;

        Mat4 proj = Mat4::screenOrtho((float)screenW, (float)screenH);
        glUniformMatrix4fv(uMVP_, 1, GL_FALSE, proj.m);
        glUniformMatrix4fv(uModel_, 1, GL_FALSE, Mat4::identity().m);
        glUniform3f(uColor_, color.x, color.y, color.z);
        glBindTexture(GL_TEXTURE_2D, fontTex_);

        glBindBuffer(GL_ARRAY_BUFFER, textVbo_);
        glBufferData(GL_ARRAY_BUFFER, verts.size()*sizeof(float), verts.data(), GL_DYNAMIC_DRAW);
        GPUMesh gm{ textVbo_, (int)(verts.size()/8), GL_TRIANGLES };

        glEnable(GL_BLEND);
        glBlendFunc(GL_ONE, GL_ONE); // additive: latar (hitam di atlas) tidak menimpa apa pun
        drawMesh(gm);
        glDisable(GL_BLEND);
    }

    // Renderer generik: hanya menggambar apa yang Game taruh di uiRects/uiTexts tiap frame.
    void drawUI(const Scene& s, int screenW, int screenH) {
        glDisable(GL_DEPTH_TEST);
        glUniform1f(uAmbient_, 1.0f);
        glUniform3f(uLightColor_, 0, 0, 0);
        for (const UIRect& r : s.uiRects) drawUIQuad(r.x, r.y, r.w, r.h, r.color, screenW, screenH);
        for (const UIText& t : s.uiTexts) drawText(t.text, t.x, t.y, t.scale, t.color, screenW, screenH);
        glEnable(GL_DEPTH_TEST);
    }

    void uploadMesh(const char* name, const Mesh& cpu) {
        GPUMesh gm;
        glGenBuffers(1, &gm.vbo);
        glBindBuffer(GL_ARRAY_BUFFER, gm.vbo);
        glBufferData(GL_ARRAY_BUFFER, cpu.vertices.size()*sizeof(float), cpu.vertices.data(), GL_STATIC_DRAW);
        gm.count = cpu.vertexCount;
        gm.mode = cpu.mode == DrawMode::TriangleStrip ? GL_TRIANGLE_STRIP : GL_TRIANGLES;
        meshes_[name] = gm;
    }

    void makeWhiteTexture() {
        uint8_t px[4] = {255,255,255,255};
        glGenTextures(1, &whiteTex_);
        glBindTexture(GL_TEXTURE_2D, whiteTex_);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    }

    void loadFontAtlas() {
        std::vector<uint8_t> raw; DecodedImage img;
        if (assets_ && assets_->readBinary("textures/font.bmp", raw) && decodeBMP(raw, img)) {
            glGenTextures(1, &fontTex_);
            glBindTexture(GL_TEXTURE_2D, fontTex_);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img.width, img.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img.rgba.data());
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        } else {
            LOG("font atlas gagal dimuat, teks tidak akan tampil");
            fontTex_ = whiteTex_;
        }
    }

    GLuint getTexture(const std::string& name) {
        if (name.empty()) return whiteTex_;
        auto it = textures_.find(name);
        if (it != textures_.end()) return it->second;

        GLuint tex = whiteTex_;
        std::vector<uint8_t> raw; DecodedImage img;
        if (assets_ && assets_->readBinary("textures/" + name, raw) && decodeBMP(raw, img)) {
            glGenTextures(1, &tex);
            glBindTexture(GL_TEXTURE_2D, tex);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img.width, img.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img.rgba.data());
            glGenerateMipmap(GL_TEXTURE_2D);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        } else {
            LOG("texture gagal dimuat: %s", name.c_str());
        }
        textures_[name] = tex;
        return tex;
    }

    EGLDisplay dpy_ = EGL_NO_DISPLAY; EGLSurface surf_ = EGL_NO_SURFACE; EGLContext ctx_ = EGL_NO_CONTEXT;
    GLuint prog_ = 0;
    GLint uMVP_ = -1, uModel_ = -1, uColor_ = -1, uTex_ = -1;
    GLint uLightDir_ = -1, uLightColor_ = -1, uAmbient_ = -1;
    GLuint whiteTex_ = 0, fontTex_ = 0, textVbo_ = 0;
    AssetManager* assets_ = nullptr;
    std::unordered_map<std::string, GPUMesh> meshes_;
    std::unordered_map<std::string, GLuint> textures_;
};

std::unique_ptr<Renderer> createGLESRenderer() { return std::make_unique<GLESRenderer>(); }
}
