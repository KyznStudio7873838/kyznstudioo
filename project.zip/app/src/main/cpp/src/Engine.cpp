#include "kyzn/Engine.h"
#include <time.h>
namespace kyzn {
std::unique_ptr<Renderer> createGLESRenderer();

static double nowSec() {
    timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

Engine::Engine(std::unique_ptr<Game> game) : game_(std::move(game)) {}

bool Engine::attachWindow(ANativeWindow* w) {
    renderer_ = createGLESRenderer();
    renderer_->setAssetManager(&assets_);
    if (!renderer_->init(w)) { renderer_.reset(); return false; }
    if (!started_) { game_->onStart(scene_); started_ = true; }
    last_ = nowSec();
    return true;
}

void Engine::detachWindow() {
    if (renderer_) { renderer_->shutdown(); renderer_.reset(); }
}

void Engine::tick() {
    if (!renderer_) return;
    double t = nowSec();
    float dt = float(t - last_); last_ = t;
    game_->onUpdate(scene_, dt);
    renderer_->render(scene_);
}
}
