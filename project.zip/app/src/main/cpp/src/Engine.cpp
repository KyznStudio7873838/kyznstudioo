#include "kyzn/Engine.h"
#include <time.h>
namespace kyzn {
std::unique_ptr<Renderer> createGLESRenderer();

static double nowSec() {
    timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

Engine::Engine(std::unique_ptr<Game> game) : game_(std::move(game)) {}

bool Engine::attachWindow(ANativeWindow* w) {
    renderer_ = createGLESRenderer();
    renderer_->setAssetManager(&assets_);
    if (!renderer_->init(w)) { renderer_.reset(); return false; }
    if (!started_) { game_->onStart(scene_); started_ = true; }
    last_ = nowSec();
    return true;
}

void Engine::detachWindow() {
    if (renderer_) { renderer_->shutdown(); renderer_.reset(); }
}

void Engine::feedTouch(int action, float x, float y) {
    if (action == 0) {
        touch_.down = true; touch_.justPressed = true;
        touch_.x = x; touch_.y = y; touch_.dx = 0; touch_.dy = 0;
        lastTouchX_ = x; lastTouchY_ = y;
    } else if (action == 1 && touch_.down) {
        touch_.dx += x - lastTouchX_;
        touch_.dy += y - lastTouchY_;
        touch_.x = x; touch_.y = y;
        lastTouchX_ = x; lastTouchY_ = y;
    } else {
        touch_.down = false; touch_.justReleased = true;
        touch_.dx = 0; touch_.dy = 0;
    }
}

void Engine::tick() {
    if (!renderer_) return;
    double t = nowSec();
    float dt = float(t - last_); last_ = t;
    game_->onUpdate(scene_, dt, touch_);
    touch_.dx = 0; touch_.dy = 0;
    touch_.justPressed = false; touch_.justReleased = false;
    renderer_->render(scene_);
}
}
