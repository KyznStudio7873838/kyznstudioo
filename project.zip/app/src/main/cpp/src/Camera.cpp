#include "kyzn/Camera.h"
namespace kyzn {

Mat4 buildViewProj(const Camera& c, float aspect) {
    Mat4 proj = c.mode == CameraMode::Ortho2D
        ? Mat4::ortho(c.orthoHeight * aspect, c.orthoHeight, -100, 100)
        : Mat4::perspective(c.fov, aspect, c.nearZ, c.farZ);
    Mat4 view = Mat4::translate({-c.pos.x, -c.pos.y, c.mode == CameraMode::Ortho2D ? 0 : -c.pos.z});
    return Mat4::mul(proj, view);
}

bool projectToScreen(const Mat4& m, Vec3 p, int screenW, int screenH, float& outX, float& outY) {
    float x = m.m[0]*p.x + m.m[4]*p.y + m.m[8]*p.z  + m.m[12];
    float y = m.m[1]*p.x + m.m[5]*p.y + m.m[9]*p.z  + m.m[13];
    float w = m.m[3]*p.x + m.m[7]*p.y + m.m[11]*p.z + m.m[15];
    if (w <= 0.0001f) return false;
    float ndcX = x / w, ndcY = y / w;
    outX = (ndcX * 0.5f + 0.5f) * screenW;
    outY = (1.0f - (ndcY * 0.5f + 0.5f)) * screenH;
    return true;
}
}
