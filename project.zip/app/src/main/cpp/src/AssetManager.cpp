#include "kyzn/AssetManager.h"
#include <android/asset_manager.h>
namespace kyzn {
bool AssetManager::readBinary(const std::string& path, std::vector<uint8_t>& out) const {
    if (!mgr_) return false;
    AAsset* a = AAssetManager_open(mgr_, path.c_str(), AASSET_MODE_BUFFER);
    if (!a) return false;
    off_t len = AAsset_getLength(a);
    out.resize((size_t)len);
    AAsset_read(a, out.data(), (size_t)len);
    AAsset_close(a);
    return true;
}
}
