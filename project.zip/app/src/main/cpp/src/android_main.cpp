#include <android_native_app_glue.h>
#include "kyzn/Engine.h"

using namespace kyzn;

// Contoh: beberapa object berbeda -> uji Object System + Material/Texture.
class DemoGame : public Game {
public:
    void onStart(Scene& s) override {
        s.camera.mode = CameraMode::Perspective3D;
        s.camera.pos = {0, 1.5f, 6};

        Entity floor; floor.mesh = "cube"; floor.texture = "";
        floor.t.pos = {0, -1, 0}; floor.t.scale = {8, 0.2f, 8};
        floor.color = {0.35f, 0.35f, 0.4f};
        s.entities.push_back(floor);

        Entity cubeTex; cubeTex.mesh = "cube"; cubeTex.texture = "checker.bmp";
        cubeTex.t.pos = {0, 0.5f, 0};
        s.entities.push_back(cubeTex); // index 1: kubus bertekstur, ikut berputar

        Entity cubeRed; cubeRed.mesh = "cube"; cubeRed.texture = "";
        cubeRed.t.pos = {-2, 0.5f, 0}; cubeRed.color = {0.9f, 0.2f, 0.2f};
        s.entities.push_back(cubeRed); // object kedua, warna polos

        Entity quadTex; quadTex.mesh = "quad"; quadTex.texture = "checker.bmp";
        quadTex.t.pos = {2, 0.5f, 0}; quadTex.t.scale = {1.5f, 1.5f, 1};
        s.entities.push_back(quadTex); // object ketiga, mesh berbeda (quad)
    }

    void onUpdate(Scene& s, float dt) override {
        s.entities[1].t.rotY += dt;
        s.entities[3].t.rotZ += dt * 0.6f;
    }
};

static void onCmd(android_app* app, int32_t cmd) {
    auto* eng = static_cast<Engine*>(app->userData);
    if (cmd == APP_CMD_INIT_WINDOW && app->window) eng->attachWindow(app->window);
    else if (cmd == APP_CMD_TERM_WINDOW) eng->detachWindow();
}

void android_main(android_app* app) {
    Engine engine(std::make_unique<DemoGame>());
    engine.assets().attach(app->activity->assetManager);
    app->userData = &engine;
    app->onAppCmd = onCmd;
    while (!app->destroyRequested) {
        int events; android_poll_source* src;
        while (ALooper_pollAll(engine.hasWindow() ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) return;
        }
        engine.tick();
    }
}
