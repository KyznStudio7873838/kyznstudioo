#include <android_native_app_glue.h>
#include "kyzn/Engine.h"

using namespace kyzn;

// Contoh game: kotak berputar. Ganti mode kamera ke Perspective3D untuk uji 3D.
class DemoGame : public Game {
public:
    void onStart(Scene& s) override {
        s.camera.mode = CameraMode::Ortho2D;
        Entity e; e.t.scale = {3, 3, 1}; e.color = {0.2f, 0.8f, 0.6f};
        s.entities.push_back(e);
    }
    void onUpdate(Scene& s, float dt) override { s.entities[0].t.rotZ += dt; }
};

static void onCmd(android_app* app, int32_t cmd) {
    auto* eng = static_cast<Engine*>(app->userData);
    if (cmd == APP_CMD_INIT_WINDOW && app->window) eng->attachWindow(app->window);
    else if (cmd == APP_CMD_TERM_WINDOW) eng->detachWindow();
}

void android_main(android_app* app) {
    Engine engine(std::make_unique<DemoGame>());
    app->userData = &engine;
    app->onAppCmd = onCmd;
    while (!app->destroyRequested) {
        int events; android_poll_source* src;
        while (ALooper_pollAll(engine.hasWindow() ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) return;
        }
        engine.tick();
    }
}
