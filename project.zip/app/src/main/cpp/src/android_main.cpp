#include <android_native_app_glue.h>
#include <android/input.h>
#include <cmath>
#include "kyzn/Engine.h"
#include "kyzn/Physics.h"
#include "kyzn/Camera.h"
#include "kyzn/EditorUI.h"
#include "kyzn/SceneIO.h"

using namespace kyzn;

// Demo game + editor sederhana.
// Mode Play: drag di layar gerakkan player (kubus biru), kena gravitasi & tabrakan.
// Mode Edit (tombol kuning kiri-atas): tap object utk pilih & drag utk pindah,
//   tombol hijau = tambah, merah = hapus, biru = simpan, ungu = muat.
class DemoGame : public Game {
public:
    explicit DemoGame(std::string savePath) : savePath_(std::move(savePath)) {}

    void onStart(Scene& s) override {
        s.camera.mode = CameraMode::Perspective3D;
        s.camera.pos = {0, 1.5f, 6};

        if (loadScene(s, savePath_)) return; // sudah ada scene tersimpan, pakai itu

        Entity floor; floor.name = "floor"; floor.mesh = "cube";
        floor.t.pos = {0, -1, 0}; floor.t.scale = {10, 0.2f, 10};
        floor.color = {0.35f, 0.35f, 0.4f};
        s.entities.push_back(floor);

        Entity cubeTex; cubeTex.name = "deco_spin"; cubeTex.mesh = "cube"; cubeTex.texture = "checker.bmp";
        cubeTex.t.pos = {-2.5f, 0.5f, -1};
        s.entities.push_back(cubeTex);

        Entity cubeRed; cubeRed.name = "deco_red"; cubeRed.mesh = "cube";
        cubeRed.t.pos = {2.5f, 0.5f, -1}; cubeRed.color = {0.9f, 0.2f, 0.2f};
        s.entities.push_back(cubeRed);

        Entity cubeWhite; cubeWhite.name = "deco_white"; cubeWhite.mesh = "cube";
        cubeWhite.t.pos = {0, 0.5f, -2.5f}; cubeWhite.color = {0.85f, 0.85f, 0.85f};
        s.entities.push_back(cubeWhite);

        Entity quadTex; quadTex.name = "deco_quad"; quadTex.mesh = "quad";
        quadTex.texture = "checker.bmp"; quadTex.solid = false;
        quadTex.t.pos = {0, 0.5f, -3}; quadTex.t.scale = {1.5f, 1.5f, 1};
        s.entities.push_back(quadTex);

        Entity player; player.name = "player"; player.mesh = "cube";
        player.color = {0.25f, 0.55f, 0.95f};
        player.t.pos = {0, 3, 1}; player.t.scale = {0.6f, 0.6f, 0.6f};
        player.dynamic = true;
        s.entities.push_back(player);
    }

    void onUpdate(Scene& s, float dt, const TouchInput& in) override {
        handleUIAndPicking(s, in);

        if (s.editMode) {
            // Mode edit: drag object terpilih, tanpa fisika, biar presisi naruh posisi.
            if (s.selectedEntity >= 0 && in.down) {
                Entity& e = s.entities[s.selectedEntity];
                e.t.pos.x += in.dx * 0.01f;
                e.t.pos.z += in.dy * 0.01f;
            }
            return;
        }

        // Mode play: animasi dekorasi + kontrol player + fisika.
        int di = findByName(s, "deco_spin"); if (di >= 0) s.entities[di].t.rotY += dt;
        int qi = findByName(s, "deco_quad"); if (qi >= 0) s.entities[qi].t.rotZ += dt * 0.6f;

        int pi = findByName(s, "player");
        if (pi >= 0) {
            Entity& player = s.entities[pi];
            const float sens = 3.0f;
            if (in.down) {
                player.velocity.x = in.dx * sens * 0.03f;
                player.velocity.z = in.dy * sens * 0.03f;
            } else {
                player.velocity.x *= 0.85f;
                player.velocity.z *= 0.85f;
            }
            stepPhysics(s, dt);
            s.camera.pos = { player.t.pos.x, player.t.pos.y + 1.5f, player.t.pos.z + 4.0f };
        }
    }

private:
    void handleUIAndPicking(Scene& s, const TouchInput& in) {
        if (!in.justPressed) return;

        if (editorui::hit(editorui::EDIT_BTN, in.x, in.y)) {
            s.editMode = !s.editMode;
            s.selectedEntity = -1;
            return;
        }
        if (!s.editMode) return; // tombol lain hanya aktif saat edit mode

        if (editorui::hit(editorui::ADD_BTN, in.x, in.y)) {
            Entity e; e.name = "obj" + std::to_string(counter_++);
            e.mesh = "cube"; e.color = {0.7f, 0.7f, 0.2f};
            e.t.pos = { s.camera.pos.x, s.camera.pos.y - 0.5f, s.camera.pos.z - 3.0f };
            e.t.scale = {0.6f, 0.6f, 0.6f};
            s.entities.push_back(e);
            s.selectedEntity = (int)s.entities.size() - 1;
            return;
        }
        if (editorui::hit(editorui::DEL_BTN, in.x, in.y)) {
            if (s.selectedEntity >= 0) {
                const std::string& nm = s.entities[s.selectedEntity].name;
                if (nm != "player" && nm != "floor") { // lindungi object inti
                    s.entities.erase(s.entities.begin() + s.selectedEntity);
                    s.selectedEntity = -1;
                }
            }
            return;
        }
        if (editorui::hit(editorui::SAVE_BTN, in.x, in.y)) { saveScene(s, savePath_); return; }
        if (editorui::hit(editorui::LOAD_BTN, in.x, in.y)) { loadScene(s, savePath_); s.selectedEntity = -1; return; }

        // Tidak kena tombol -> coba pilih object terdekat dari titik sentuh.
        float aspect = (float)s.screenW / (float)s.screenH;
        Mat4 vp = buildViewProj(s.camera, aspect);
        int best = -1; float bestDist = 90.0f; // radius pilih ~90px
        for (size_t i = 0; i < s.entities.size(); i++) {
            float sx, sy;
            if (!projectToScreen(vp, s.entities[i].t.pos, s.screenW, s.screenH, sx, sy)) continue;
            float d = sqrtf((sx-in.x)*(sx-in.x) + (sy-in.y)*(sy-in.y));
            if (d < bestDist) { bestDist = d; best = (int)i; }
        }
        s.selectedEntity = best;
    }

    std::string savePath_;
    int counter_ = 0;
};

static void onAppCmd(android_app* app, int32_t cmd) {
    auto* eng = static_cast<Engine*>(app->userData);
    if (cmd == APP_CMD_INIT_WINDOW && app->window) eng->attachWindow(app->window);
    else if (cmd == APP_CMD_TERM_WINDOW) eng->detachWindow();
}

static int32_t onInputEvent(android_app* app, AInputEvent* event) {
    auto* eng = static_cast<Engine*>(app->userData);
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
        int32_t action = AMotionEvent_getAction(event) & AMOTION_EVENT_ACTION_MASK;
        float x = AMotionEvent_getX(event, 0);
        float y = AMotionEvent_getY(event, 0);
        int a = (action == AMOTION_EVENT_ACTION_DOWN) ? 0
              : (action == AMOTION_EVENT_ACTION_MOVE) ? 1 : 2;
        eng->feedTouch(a, x, y);
        return 1;
    }
    return 0;
}

void android_main(android_app* app) {
    std::string savePath = std::string(app->activity->internalDataPath) + "/scene.kyzn";
    Engine engine(std::make_unique<DemoGame>(savePath));
    engine.assets().attach(app->activity->assetManager);
    app->userData = &engine;
    app->onAppCmd = onAppCmd;
    app->onInputEvent = onInputEvent;
    while (!app->destroyRequested) {
        int events; android_poll_source* src;
        while (ALooper_pollAll(engine.hasWindow() ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) return;
        }
        engine.tick();
    }
}
