#include <android_native_app_glue.h>
#include <android/input.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include "kyzn/Engine.h"
#include "kyzn/Physics.h"
#include "kyzn/Camera.h"
#include "kyzn/EditorUI.h"
#include "kyzn/SceneIO.h"

using namespace kyzn;

// ===== KyznStudio: demo game + UI editor bertab (Scene / Hierarchy / Inspector / Build) =====
static const Vec3 COL_PANEL   {0.12f,0.13f,0.17f};
static const Vec3 COL_ROW     {0.18f,0.19f,0.24f};
static const Vec3 COL_ROW_SEL {0.25f,0.45f,0.85f};
static const Vec3 COL_TEXT    {0.92f,0.93f,0.95f};
static const Vec3 COL_TAB_ON  {0.25f,0.45f,0.85f};
static const Vec3 COL_TAB_OFF {0.15f,0.16f,0.20f};
static const Vec3 COL_BTN_ADD {0.20f,0.80f,0.30f};
static const Vec3 COL_BTN_DEL {0.85f,0.20f,0.20f};
static const Vec3 COL_BTN_IO  {0.20f,0.50f,0.90f};
static const Vec3 COL_BTN_MODE{0.90f,0.80f,0.10f};

static std::string upper(std::string s) { for (auto& c : s) c = (char)toupper((unsigned char)c); return s; }
static std::string fmt(const char* f, float v) { char b[32]; snprintf(b, sizeof b, f, v); return b; }

class DemoGame : public Game {
public:
    explicit DemoGame(std::string savePath) : savePath_(std::move(savePath)) {}

    void onStart(Scene& s) override {
        s.camera.mode = CameraMode::Perspective3D;
        s.camera.pos = {0, 1.5f, 6};
        if (loadScene(s, savePath_)) return;

        Entity floor; floor.name = "floor"; floor.mesh = "cube";
        floor.t.pos = {0, -1, 0}; floor.t.scale = {10, 0.2f, 10};
        floor.color = {0.35f, 0.35f, 0.4f};
        s.entities.push_back(floor);

        Entity cubeTex; cubeTex.name = "deco_spin"; cubeTex.mesh = "cube"; cubeTex.texture = "checker.bmp";
        cubeTex.t.pos = {-2.5f, 0.5f, -1};
        s.entities.push_back(cubeTex);

        Entity cubeRed; cubeRed.name = "deco_red"; cubeRed.mesh = "cube";
        cubeRed.t.pos = {2.5f, 0.5f, -1}; cubeRed.color = {0.9f, 0.2f, 0.2f};
        s.entities.push_back(cubeRed);

        Entity cubeWhite; cubeWhite.name = "deco_white"; cubeWhite.mesh = "cube";
        cubeWhite.t.pos = {0, 0.5f, -2.5f}; cubeWhite.color = {0.85f, 0.85f, 0.85f};
        s.entities.push_back(cubeWhite);

        Entity quadTex; quadTex.name = "deco_quad"; quadTex.mesh = "quad";
        quadTex.texture = "checker.bmp"; quadTex.solid = false;
        quadTex.t.pos = {0, 0.5f, -3}; quadTex.t.scale = {1.5f, 1.5f, 1};
        s.entities.push_back(quadTex);

        Entity player; player.name = "player"; player.mesh = "cube";
        player.color = {0.25f, 0.55f, 0.95f};
        player.t.pos = {0, 3, 1}; player.t.scale = {0.6f, 0.6f, 0.6f};
        player.dynamic = true;
        s.entities.push_back(player);
    }

    void onUpdate(Scene& s, float dt, const TouchInput& in) override {
        fps_ = fps_ * 0.9f + (dt > 0.0001f ? (1.0f/dt) : fps_) * 0.1f;

        s.uiRects.clear(); s.uiTexts.clear();
        bool tapUsed = buildTabBar(s, in);

        switch (s.activeTab) {
            case 0: updateSceneTab(s, in, dt, tapUsed); break;
            case 1: buildHierarchyTab(s, in, tapUsed); break;
            case 2: buildInspectorTab(s, in, tapUsed); break;
            case 3: buildBuildTab(s); break;
        }
    }

private:
    // ---------- Tab bar (selalu ada di bawah) ----------
    bool buildTabBar(Scene& s, const TouchInput& in) {
        const char* names[4] = {"SCENE","HIER","INSP","BUILD"};
        float tw = s.screenW / 4.0f, th = 110, ty = s.screenH - th;
        for (int i = 0; i < 4; i++) {
            float tx = i * tw;
            Vec3 c = (s.activeTab == i) ? COL_TAB_ON : COL_TAB_OFF;
            s.uiRects.push_back({tx+2, ty, tw-4, th, c});
            s.uiTexts.push_back({names[i], tx + tw*0.5f - (float)strlen(names[i])*3.0f*3.0f*0.5f, ty + th*0.5f - 10, 3.0f, COL_TEXT});
            if (in.justPressed && in.x>=tx && in.x<=tx+tw && in.y>=ty && in.y<=ty+th) {
                s.activeTab = i;
                return true;
            }
        }
        return false;
    }

    // ---------- Tab 0: Scene (viewport 3D + kontrol edit/play) ----------
    void updateSceneTab(Scene& s, const TouchInput& in, float dt, bool tapUsed) {
        editorui::Btn modeBtn{20,20,220,90};
        s.uiRects.push_back({modeBtn.x, modeBtn.y, modeBtn.w, modeBtn.h, COL_BTN_MODE});
        s.uiTexts.push_back({s.editMode ? "PLAY" : "EDIT", modeBtn.x+40, modeBtn.y+28, 3.0f, {0.05f,0.05f,0.05f}});

        editorui::Btn addBtn{260,20,180,90}, delBtn{460,20,180,90}, saveBtn{660,20,180,90}, loadBtn{860,20,180,90};
        if (s.editMode) {
            s.uiRects.push_back({addBtn.x,addBtn.y,addBtn.w,addBtn.h, COL_BTN_ADD});
            s.uiTexts.push_back({"ADD", addBtn.x+50, addBtn.y+28, 3.0f, {0,0,0}});
            s.uiRects.push_back({delBtn.x,delBtn.y,delBtn.w,delBtn.h, COL_BTN_DEL});
            s.uiTexts.push_back({"DEL", delBtn.x+50, delBtn.y+28, 3.0f, {0,0,0}});
            s.uiRects.push_back({saveBtn.x,saveBtn.y,saveBtn.w,saveBtn.h, COL_BTN_IO});
            s.uiTexts.push_back({"SAVE", saveBtn.x+35, saveBtn.y+28, 3.0f, {0,0,0}});
            s.uiRects.push_back({loadBtn.x,loadBtn.y,loadBtn.w,loadBtn.h, COL_BTN_IO});
            s.uiTexts.push_back({"LOAD", loadBtn.x+35, loadBtn.y+28, 3.0f, {0,0,0}});
        }

        if (!tapUsed && in.justPressed) {
            if (editorui::hit(modeBtn, in.x, in.y)) { s.editMode = !s.editMode; s.selectedEntity = -1; tapUsed = true; }
            else if (s.editMode && editorui::hit(addBtn, in.x, in.y)) {
                Entity e; e.name = "obj" + std::to_string(counter_++);
                e.mesh = "cube"; e.color = {0.7f,0.7f,0.2f};
                e.t.pos = { s.camera.pos.x, s.camera.pos.y - 0.5f, s.camera.pos.z - 3.0f };
                e.t.scale = {0.6f,0.6f,0.6f};
                s.entities.push_back(e); s.selectedEntity = (int)s.entities.size()-1; tapUsed = true;
            } else if (s.editMode && editorui::hit(delBtn, in.x, in.y)) {
                if (s.selectedEntity >= 0) {
                    const std::string& nm = s.entities[s.selectedEntity].name;
                    if (nm != "player" && nm != "floor") { s.entities.erase(s.entities.begin()+s.selectedEntity); s.selectedEntity = -1; }
                }
                tapUsed = true;
            } else if (s.editMode && editorui::hit(saveBtn, in.x, in.y)) { saveScene(s, savePath_); tapUsed = true; }
            else if (s.editMode && editorui::hit(loadBtn, in.x, in.y)) { loadScene(s, savePath_); s.selectedEntity = -1; tapUsed = true; }
        }

        if (s.editMode) {
            if (!tapUsed && in.justPressed) {
                float aspect = (float)s.screenW / (float)s.screenH;
                Mat4 vp = buildViewProj(s.camera, aspect);
                int best = -1; float bestDist = 90.0f;
                for (size_t i = 0; i < s.entities.size(); i++) {
                    float sx, sy;
                    if (!projectToScreen(vp, s.entities[i].t.pos, s.screenW, s.screenH, sx, sy)) continue;
                    float d = sqrtf((sx-in.x)*(sx-in.x)+(sy-in.y)*(sy-in.y));
                    if (d < bestDist) { bestDist = d; best = (int)i; }
                }
                s.selectedEntity = best;
            }
            if (s.selectedEntity >= 0 && in.down && !in.justPressed) {
                Entity& e = s.entities[s.selectedEntity];
                e.t.pos.x += in.dx * 0.01f;
                e.t.pos.z += in.dy * 0.01f;
            }
            return; // fisika/gameplay nonaktif saat edit
        }

        int di = findByName(s, "deco_spin"); if (di >= 0) s.entities[di].t.rotY += dt;
        int qi = findByName(s, "deco_quad"); if (qi >= 0) s.entities[qi].t.rotZ += dt * 0.6f;

        int pi = findByName(s, "player");
        if (pi >= 0) {
            Entity& player = s.entities[pi];
            const float sens = 3.0f;
            if (in.down && !tapUsed) {
                player.velocity.x = in.dx * sens * 0.03f;
                player.velocity.z = in.dy * sens * 0.03f;
            } else if (!in.down) {
                player.velocity.x *= 0.85f; player.velocity.z *= 0.85f;
            }
            stepPhysics(s, dt);
            s.camera.pos = { player.t.pos.x, player.t.pos.y + 1.5f, player.t.pos.z + 4.0f };
        }
    }

    // ---------- Tab 1: Hierarchy (daftar semua object, tap utk pilih) ----------
    void buildHierarchyTab(Scene& s, const TouchInput& in, bool tapUsed) {
        s.uiRects.push_back({20, 20, (float)s.screenW-40, (float)s.screenH-160, COL_PANEL});
        s.uiTexts.push_back({"HIERARCHY", 40, 35, 3.0f, COL_TEXT});
        float rowH = 90, y0 = 90;
        for (size_t i = 0; i < s.entities.size(); i++) {
            float ry = y0 + i*(rowH+8);
            if (ry + rowH > s.screenH - 170) break; // di luar layar, potong (belum ada scroll)
            bool sel = ((int)i == s.selectedEntity);
            s.uiRects.push_back({40, ry, (float)s.screenW-80, rowH, sel?COL_ROW_SEL:COL_ROW});
            s.uiTexts.push_back({upper(s.entities[i].name) + " [" + upper(s.entities[i].mesh) + "]", 60, ry+30, 2.5f, COL_TEXT});
            if (!tapUsed && in.justPressed && in.x>=40 && in.x<=s.screenW-40 && in.y>=ry && in.y<=ry+rowH) {
                s.selectedEntity = (int)i;
            }
        }
    }

    // ---------- Tab 2: Inspector (edit posisi/rotasi lewat tombol -/+) ----------
    void buildInspectorTab(Scene& s, const TouchInput& in, bool tapUsed) {
        s.uiRects.push_back({20, 20, (float)s.screenW-40, (float)s.screenH-160, COL_PANEL});
        s.uiTexts.push_back({"INSPECTOR", 40, 35, 3.0f, COL_TEXT});

        if (s.selectedEntity < 0 || s.selectedEntity >= (int)s.entities.size()) {
            s.uiTexts.push_back({"NO SELECTION - PICK IN HIER TAB", 40, 110, 2.5f, COL_TEXT});
            return;
        }
        Entity& e = s.entities[s.selectedEntity];
        s.uiTexts.push_back({"NAME: " + upper(e.name), 40, 100, 2.5f, COL_TEXT});

        struct Field { const char* label; float* val; float step; };
        Field fields[4] = {
            {"POS X", &e.t.pos.x, 0.2f}, {"POS Y", &e.t.pos.y, 0.2f},
            {"POS Z", &e.t.pos.z, 0.2f}, {"ROT Y", &e.t.rotY, 0.2f},
        };
        float rowH = 90, y0 = 170;
        for (int i = 0; i < 4; i++) {
            float ry = y0 + i*(rowH+10);
            s.uiRects.push_back({40, ry, (float)s.screenW-80, rowH, COL_ROW});
            s.uiTexts.push_back({std::string(fields[i].label) + ": " + fmt("%.1f", *fields[i].val), 60, ry+30, 2.5f, COL_TEXT});

            editorui::Btn minus{ (float)s.screenW-220, ry+5, 85, rowH-10 };
            editorui::Btn plus { (float)s.screenW-125, ry+5, 85, rowH-10 };
            s.uiRects.push_back({minus.x,minus.y,minus.w,minus.h, COL_BTN_DEL});
            s.uiTexts.push_back({"-", minus.x+35, minus.y+22, 3.0f, {0,0,0}});
            s.uiRects.push_back({plus.x,plus.y,plus.w,plus.h, COL_BTN_ADD});
            s.uiTexts.push_back({"+", plus.x+35, plus.y+22, 3.0f, {0,0,0}});

            if (!tapUsed && in.justPressed) {
                if (editorui::hit(minus, in.x, in.y)) *fields[i].val -= fields[i].step;
                else if (editorui::hit(plus, in.x, in.y)) *fields[i].val += fields[i].step;
            }
        }

        if (e.name != "player" && e.name != "floor") {
            editorui::Btn delBtn{40, y0 + 4*(rowH+10) + 10, (float)s.screenW-80, rowH};
            s.uiRects.push_back({delBtn.x,delBtn.y,delBtn.w,delBtn.h, COL_BTN_DEL});
            s.uiTexts.push_back({"DELETE OBJECT", delBtn.x+40, delBtn.y+30, 2.5f, {0,0,0}});
            if (!tapUsed && in.justPressed && editorui::hit(delBtn, in.x, in.y)) {
                s.entities.erase(s.entities.begin()+s.selectedEntity); s.selectedEntity = -1;
            }
        }
    }

    // ---------- Tab 3: Build (info + panduan build APK) ----------
    void buildBuildTab(Scene& s) {
        s.uiRects.push_back({20, 20, (float)s.screenW-40, (float)s.screenH-160, COL_PANEL});
        s.uiTexts.push_back({"KYZNSTUDIO ENGINE V0.1", 40, 40, 3.0f, COL_TEXT});
        s.uiTexts.push_back({"ENTITIES: " + std::to_string((int)s.entities.size()), 40, 110, 2.5f, COL_TEXT});
        s.uiTexts.push_back({"FPS: " + fmt("%.0f", fps_), 40, 160, 2.5f, COL_TEXT});
        s.uiTexts.push_back({"CARA BUILD APK -", 40, 250, 2.5f, COL_TEXT});
        s.uiTexts.push_back({"1. ZIP PROJECT INI", 40, 300, 2.5f, COL_TEXT});
        s.uiTexts.push_back({"2. UPLOAD KE GITHUB", 40, 350, 2.5f, COL_TEXT});
        s.uiTexts.push_back({"3. JALANKAN ACTIONS", 40, 400, 2.5f, COL_TEXT});
        s.uiTexts.push_back({"4. DOWNLOAD APK-NYA", 40, 450, 2.5f, COL_TEXT});
    }

    std::string savePath_;
    int counter_ = 0;
    float fps_ = 60.0f;
};

static void onAppCmd(android_app* app, int32_t cmd) {
    auto* eng = static_cast<Engine*>(app->userData);
    if (cmd == APP_CMD_INIT_WINDOW && app->window) eng->attachWindow(app->window);
    else if (cmd == APP_CMD_TERM_WINDOW) eng->detachWindow();
}

static int32_t onInputEvent(android_app* app, AInputEvent* event) {
    auto* eng = static_cast<Engine*>(app->userData);
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
        int32_t action = AMotionEvent_getAction(event) & AMOTION_EVENT_ACTION_MASK;
        float x = AMotionEvent_getX(event, 0);
        float y = AMotionEvent_getY(event, 0);
        int a = (action == AMOTION_EVENT_ACTION_DOWN) ? 0
              : (action == AMOTION_EVENT_ACTION_MOVE) ? 1 : 2;
        eng->feedTouch(a, x, y);
        return 1;
    }
    return 0;
}

void android_main(android_app* app) {
    std::string savePath = std::string(app->activity->internalDataPath) + "/scene.kyzn";
    Engine engine(std::make_unique<DemoGame>(savePath));
    engine.assets().attach(app->activity->assetManager);
    app->userData = &engine;
    app->onAppCmd = onAppCmd;
    app->onInputEvent = onInputEvent;
    while (!app->destroyRequested) {
        int events; android_poll_source* src;
        while (ALooper_pollAll(engine.hasWindow() ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) return;
        }
        engine.tick();
    }
}
