#include "kyzn/Text.h"
#include <cctype>
#include <cstring>
namespace kyzn {
int glyphIndex(char c) {
    char u = (char)std::toupper((unsigned char)c);
    const char* p = std::strchr(FONT_CHARSET, u);
    if (!p || u == '\0') return -1;
    return (int)(p - FONT_CHARSET);
}
}
