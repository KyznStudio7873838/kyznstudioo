#include "kyzn/Mesh.h"
namespace kyzn {

Mesh makeQuad() {
    Mesh m;
    m.mode = DrawMode::TriangleStrip;
    m.vertices = {
        // pos              normal      uv
        -0.5f,-0.5f,0,   0,0,1,   0,0,
         0.5f,-0.5f,0,   0,0,1,   1,0,
        -0.5f, 0.5f,0,   0,0,1,   0,1,
         0.5f, 0.5f,0,   0,0,1,   1,1,
    };
    m.vertexCount = 4;
    return m;
}

static void face(std::vector<float>& v, float nx, float ny, float nz,
                  float ax,float ay,float az, float bx,float by,float bz,
                  float cx,float cy,float cz, float dx,float dy,float dz) {
    float verts[4][3] = {{ax,ay,az},{bx,by,bz},{cx,cy,cz},{dx,dy,dz}};
    float uv[4][2] = {{0,0},{1,0},{1,1},{0,1}};
    int idx[6] = {0,1,2, 0,2,3};
    for (int i : idx) {
        v.push_back(verts[i][0]); v.push_back(verts[i][1]); v.push_back(verts[i][2]);
        v.push_back(nx); v.push_back(ny); v.push_back(nz);
        v.push_back(uv[i][0]); v.push_back(uv[i][1]);
    }
}

Mesh makeCube() {
    Mesh m; m.mode = DrawMode::Triangles;
    auto& v = m.vertices;
    face(v,  0, 0, 1,  -.5f,-.5f,.5f,  .5f,-.5f,.5f,  .5f,.5f,.5f,  -.5f,.5f,.5f); // depan
    face(v,  0, 0,-1,   .5f,-.5f,-.5f, -.5f,-.5f,-.5f, -.5f,.5f,-.5f, .5f,.5f,-.5f); // belakang
    face(v, -1, 0, 0,  -.5f,-.5f,-.5f, -.5f,-.5f,.5f,  -.5f,.5f,.5f, -.5f,.5f,-.5f); // kiri
    face(v,  1, 0, 0,   .5f,-.5f,.5f,   .5f,-.5f,-.5f,  .5f,.5f,-.5f, .5f,.5f,.5f); // kanan
    face(v,  0, 1, 0,  -.5f,.5f,.5f,    .5f,.5f,.5f,    .5f,.5f,-.5f,-.5f,.5f,-.5f); // atas
    face(v,  0,-1, 0,  -.5f,-.5f,-.5f,  .5f,-.5f,-.5f,  .5f,-.5f,.5f,-.5f,-.5f,.5f); // bawah
    m.vertexCount = 36;
    return m;
}
}
