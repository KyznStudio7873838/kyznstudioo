#include "kyzn/Mesh.h"
namespace kyzn {

Mesh makeQuad() {
    Mesh m;
    m.mode = DrawMode::TriangleStrip;
    m.vertices = {
        -0.5f,-0.5f,0, 0,0,
         0.5f,-0.5f,0, 1,0,
        -0.5f, 0.5f,0, 0,1,
         0.5f, 0.5f,0, 1,1,
    };
    m.vertexCount = 4;
    return m;
}

Mesh makeCube() {
    Mesh m;
    m.mode = DrawMode::Triangles;
    float v[] = {
        // pos               uv        (6 wajah x 2 segitiga x 3 verts)
        -.5f,-.5f, .5f, 0,0,  .5f,-.5f, .5f, 1,0,  .5f, .5f, .5f, 1,1,
        -.5f,-.5f, .5f, 0,0,  .5f, .5f, .5f, 1,1, -.5f, .5f, .5f, 0,1,
         .5f,-.5f,-.5f, 0,0, -.5f,-.5f,-.5f, 1,0, -.5f, .5f,-.5f, 1,1,
         .5f,-.5f,-.5f, 0,0, -.5f, .5f,-.5f, 1,1,  .5f, .5f,-.5f, 0,1,
        -.5f,-.5f,-.5f, 0,0, -.5f,-.5f, .5f, 1,0, -.5f, .5f, .5f, 1,1,
        -.5f,-.5f,-.5f, 0,0, -.5f, .5f, .5f, 1,1, -.5f, .5f,-.5f, 0,1,
         .5f,-.5f, .5f, 0,0,  .5f,-.5f,-.5f, 1,0,  .5f, .5f,-.5f, 1,1,
         .5f,-.5f, .5f, 0,0,  .5f, .5f,-.5f, 1,1,  .5f, .5f, .5f, 0,1,
        -.5f, .5f, .5f, 0,0,  .5f, .5f, .5f, 1,0,  .5f, .5f,-.5f, 1,1,
        -.5f, .5f, .5f, 0,0,  .5f, .5f,-.5f, 1,1, -.5f, .5f,-.5f, 0,1,
        -.5f,-.5f,-.5f, 0,0,  .5f,-.5f,-.5f, 1,0,  .5f,-.5f, .5f, 1,1,
        -.5f,-.5f,-.5f, 0,0,  .5f,-.5f, .5f, 1,1, -.5f,-.5f, .5f, 0,1,
    };
    m.vertices.assign(v, v + sizeof(v)/sizeof(float));
    m.vertexCount = 36;
    return m;
}
}
