#include "kyzn/Texture.h"
#include <cstring>
namespace kyzn {
static uint32_t rd32(const uint8_t* p) { uint32_t v; memcpy(&v, p, 4); return v; }
static int32_t  rd32s(const uint8_t* p) { int32_t v; memcpy(&v, p, 4); return v; }
static uint16_t rd16(const uint8_t* p) { uint16_t v; memcpy(&v, p, 2); return v; }

// Mendukung BMP uncompressed 24-bit dan 32-bit (format paling umum).
bool decodeBMP(const std::vector<uint8_t>& d, DecodedImage& out) {
    if (d.size() < 54 || d[0] != 'B' || d[1] != 'M') return false;
    uint32_t dataOffset = rd32(&d[10]);
    int32_t width = rd32s(&d[18]);
    int32_t heightRaw = rd32s(&d[22]);
    uint16_t bpp = rd16(&d[28]);
    if (bpp != 24 && bpp != 32) return false;
    bool bottomUp = heightRaw > 0;
    int height = bottomUp ? heightRaw : -heightRaw;
    int bytesPerPx = bpp / 8;
    int rowSize = ((bpp * width + 31) / 32) * 4;

    out.width = width; out.height = height;
    out.rgba.resize((size_t)width * height * 4);

    for (int y = 0; y < height; y++) {
        int srcRow = bottomUp ? (height - 1 - y) : y;
        const uint8_t* row = d.data() + dataOffset + (size_t)srcRow * rowSize;
        for (int x = 0; x < width; x++) {
            const uint8_t* px = row + x * bytesPerPx;
            uint8_t b = px[0], g = px[1], r = px[2];
            uint8_t a = bytesPerPx == 4 ? px[3] : 255;
            size_t o = ((size_t)y * width + x) * 4;
            out.rgba[o+0]=r; out.rgba[o+1]=g; out.rgba[o+2]=b; out.rgba[o+3]=a;
        }
    }
    return true;
}
}
