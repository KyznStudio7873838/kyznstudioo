#pragma once
#include "Scene.h"
namespace kyzn {
// Bikin matriks view-projection dari kamera (dipakai renderer & untuk picking di editor).
Mat4 buildViewProj(const Camera& cam, float aspect);

// Proyeksikan titik dunia ke koordinat piksel layar. false jika di belakang kamera.
bool projectToScreen(const Mat4& vp, Vec3 worldPos, int screenW, int screenH, float& outX, float& outY);
}
