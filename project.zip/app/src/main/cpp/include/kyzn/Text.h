#pragma once
namespace kyzn {
// Charset & tata letak HARUS sama persis dengan assets/textures/font.bmp (lihat gen_font.py).
inline const char* FONT_CHARSET = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:-+/_()%";
inline const int FONT_COLS = 8;
inline const int FONT_CELL_W = 6;
inline const int FONT_CELL_H = 8;
inline const int GLYPH_W = 5, GLYPH_H = 7;

// -1 jika karakter tak didukung (huruf kecil otomatis di-uppercase).
int glyphIndex(char c);
}
