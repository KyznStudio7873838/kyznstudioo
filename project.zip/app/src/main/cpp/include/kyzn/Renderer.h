#pragma once
#include "Scene.h"
struct ANativeWindow;
namespace kyzn {
class AssetManager;
class Renderer {
public:
    virtual ~Renderer() = default;
    virtual void setAssetManager(AssetManager*) {}
    virtual bool init(ANativeWindow* window) = 0;
    virtual void render(Scene& scene) = 0; // non-const: renderer menulis balik screenW/H
    virtual void shutdown() = 0;
};
}
