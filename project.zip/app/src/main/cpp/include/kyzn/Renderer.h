#pragma once
#include "Scene.h"
struct ANativeWindow;
namespace kyzn {
class AssetManager;
class Renderer {
public:
    virtual ~Renderer() = default;
    virtual void setAssetManager(AssetManager*) {}
    virtual bool init(ANativeWindow* window) = 0;
    virtual void render(const Scene& scene) = 0;
    virtual void shutdown() = 0;
};
}
