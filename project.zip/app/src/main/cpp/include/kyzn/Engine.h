#pragma once
#include <memory>
#include "Renderer.h"
#include "AssetManager.h"
struct ANativeWindow;
namespace kyzn {
class Game {
public:
    virtual ~Game() = default;
    virtual void onStart(Scene&) {}
    virtual void onUpdate(Scene&, float dt) {}
};

class Engine {
public:
    explicit Engine(std::unique_ptr<Game> game);
    bool attachWindow(ANativeWindow* w);
    void detachWindow();
    bool hasWindow() const { return renderer_ != nullptr; }
    void tick();
    AssetManager& assets() { return assets_; }
private:
    std::unique_ptr<Game> game_;
    std::unique_ptr<Renderer> renderer_;
    AssetManager assets_;
    Scene scene_;
    double last_ = 0;
    bool started_ = false;
};
}
