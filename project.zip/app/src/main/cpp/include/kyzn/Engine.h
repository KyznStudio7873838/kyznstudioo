#pragma once
#include <memory>
#include "Renderer.h"
#include "AssetManager.h"
#include "Input.h"
struct ANativeWindow;
namespace kyzn {
class Game {
public:
    virtual ~Game() = default;
    virtual void onStart(Scene&) {}
    virtual void onUpdate(Scene&, float dt, const TouchInput& input) {}
};

class Engine {
public:
    explicit Engine(std::unique_ptr<Game> game);
    bool attachWindow(ANativeWindow* w);
    void detachWindow();
    bool hasWindow() const { return renderer_ != nullptr; }
    void tick();
    AssetManager& assets() { return assets_; }
    void feedTouch(int action, float x, float y); // 0=down,1=move,2=up/cancel

private:
    std::unique_ptr<Game> game_;
    std::unique_ptr<Renderer> renderer_;
    AssetManager assets_;
    Scene scene_;
    TouchInput touch_;
    float lastTouchX_ = 0, lastTouchY_ = 0;
    double last_ = 0;
    bool started_ = false;
};
}
