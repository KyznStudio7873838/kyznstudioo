#pragma once
#include <string>
#include "Scene.h"
namespace kyzn {
bool saveScene(const Scene& scene, const std::string& path);
bool loadScene(Scene& scene, const std::string& path); // isi entities dari file; false jika gagal/tak ada
}
