#pragma once
#include <vector>
namespace kyzn {
enum class DrawMode { Triangles, TriangleStrip };
// Layout tiap vertex: posisi(3) + normal(3) + uv(2) = 8 float, interleaved.
struct Mesh {
    std::vector<float> vertices;
    int vertexCount = 0;
    DrawMode mode = DrawMode::Triangles;
};
Mesh makeQuad();  // bidang datar 1x1 di plane XY, menghadap +Z
Mesh makeCube();  // kubus 1x1x1
}
