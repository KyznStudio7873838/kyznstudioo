#pragma once
#include <vector>
namespace kyzn {
enum class DrawMode { Triangles, TriangleStrip };
struct Mesh {
    std::vector<float> vertices; // interleaved: x,y,z,u,v
    int vertexCount = 0;
    DrawMode mode = DrawMode::Triangles;
};
Mesh makeQuad();  // bidang datar 1x1 di plane XY
Mesh makeCube();  // kubus 1x1x1
}
