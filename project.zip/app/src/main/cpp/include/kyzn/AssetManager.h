#pragma once
#include <vector>
#include <string>
#include <cstdint>
struct AAssetManager;
namespace kyzn {
class AssetManager {
public:
    void attach(AAssetManager* mgr) { mgr_ = mgr; }
    bool readBinary(const std::string& path, std::vector<uint8_t>& out) const;
private:
    AAssetManager* mgr_ = nullptr;
};
}
