#pragma once
#include <cmath>
namespace kyzn {
struct Vec3 { float x=0,y=0,z=0; };

struct Mat4 {
    float m[16]; // column-major
    static Mat4 identity() { Mat4 r{}; r.m[0]=r.m[5]=r.m[10]=r.m[15]=1; return r; }
    static Mat4 mul(const Mat4& a, const Mat4& b) {
        Mat4 r{};
        for (int c=0;c<4;c++) for (int rw=0;rw<4;rw++) {
            float s=0; for (int k=0;k<4;k++) s += a.m[k*4+rw]*b.m[c*4+k];
            r.m[c*4+rw]=s;
        }
        return r;
    }
    static Mat4 translate(Vec3 t) { Mat4 r=identity(); r.m[12]=t.x; r.m[13]=t.y; r.m[14]=t.z; return r; }
    static Mat4 scale(Vec3 s) { Mat4 r=identity(); r.m[0]=s.x; r.m[5]=s.y; r.m[10]=s.z; return r; }
    static Mat4 rotY(float a) { Mat4 r=identity(); float c=cosf(a), s=sinf(a); r.m[0]=c; r.m[2]=-s; r.m[8]=s; r.m[10]=c; return r; }
    static Mat4 rotZ(float a) { Mat4 r=identity(); float c=cosf(a), s=sinf(a); r.m[0]=c; r.m[1]=s; r.m[4]=-s; r.m[5]=c; return r; }
    static Mat4 ortho(float w, float h, float n, float f) {
        Mat4 r{}; r.m[0]=2/w; r.m[5]=2/h; r.m[10]=-2/(f-n); r.m[14]=-(f+n)/(f-n); r.m[15]=1; return r;
    }
    static Mat4 perspective(float fovDeg, float aspect, float n, float f) {
        float t = 1.0f/tanf(fovDeg*0.5f*3.14159265f/180.0f);
        Mat4 r{}; r.m[0]=t/aspect; r.m[5]=t; r.m[10]=(f+n)/(n-f); r.m[11]=-1; r.m[14]=2*f*n/(n-f); return r;
    }
};
}
