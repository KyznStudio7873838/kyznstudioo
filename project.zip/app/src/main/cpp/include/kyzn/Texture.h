#pragma once
#include <vector>
#include <cstdint>
namespace kyzn {
struct DecodedImage { int width = 0, height = 0; std::vector<uint8_t> rgba; };
bool decodeBMP(const std::vector<uint8_t>& data, DecodedImage& out);
}
