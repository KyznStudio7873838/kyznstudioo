#pragma once
namespace kyzn {
struct TouchInput {
    bool down = false;
    bool justPressed = false;   // true hanya 1 frame saat jari mulai sentuh
    bool justReleased = false;  // true hanya 1 frame saat jari diangkat
    float x = 0, y = 0;         // posisi sentuh terakhir (piksel layar)
    float dx = 0, dy = 0;       // pergeseran sejak frame sebelumnya, direset tiap frame
};
}
