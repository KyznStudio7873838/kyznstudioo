#pragma once
#include "Scene.h"
namespace kyzn {
// Terapkan gravitasi, integrasi posisi, dan resolusi tabrakan AABB
// untuk semua entity dynamic terhadap entity solid lainnya.
void stepPhysics(Scene& scene, float dt);
}
