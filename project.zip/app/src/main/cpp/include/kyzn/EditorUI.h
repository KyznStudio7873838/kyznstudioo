#pragma once
namespace kyzn { namespace editorui {
struct Btn { float x, y, w, h; };
inline bool hit(const Btn& b, float x, float y) {
    return x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h;
}
}}
