#pragma once
namespace kyzn { namespace editorui {
struct Btn { float x, y, w, h; float r, g, b; };

// Posisi tetap di pojok kiri-atas layar (piksel).
inline const Btn EDIT_BTN{ 20,  20, 170, 90,  0.90f, 0.80f, 0.10f}; // toggle Edit/Play, selalu tampil
inline const Btn ADD_BTN { 20, 130, 170, 90,  0.20f, 0.80f, 0.30f}; // tambah object
inline const Btn DEL_BTN { 20, 240, 170, 90,  0.85f, 0.20f, 0.20f}; // hapus object terpilih
inline const Btn SAVE_BTN{ 20, 350, 170, 90,  0.20f, 0.50f, 0.90f}; // simpan scene
inline const Btn LOAD_BTN{ 20, 460, 170, 90,  0.60f, 0.30f, 0.90f}; // muat scene

inline bool hit(const Btn& b, float x, float y) {
    return x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h;
}
}}
