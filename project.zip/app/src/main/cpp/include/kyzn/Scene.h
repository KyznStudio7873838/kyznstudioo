#pragma once
#include <vector>
#include <string>
#include "Math.h"
namespace kyzn {
struct Transform { Vec3 pos{0,0,0}; Vec3 scale{1,1,1}; float rotZ=0; float rotY=0; };
enum class CameraMode { Ortho2D, Perspective3D };
struct Camera {
    CameraMode mode = CameraMode::Ortho2D;
    Vec3 pos{0,0,3};
    float fov=60, nearZ=0.1f, farZ=100, orthoHeight=10;
};
struct Light {
    Vec3 direction{-0.4f, -1.0f, -0.3f};
    Vec3 color{1, 1, 1};
    float intensity = 1.0f;
    float ambient = 0.25f;
};
struct Entity {
    std::string name;               // dipakai untuk cari object ("player","floor",dst), bukan index
    Transform t;
    Vec3 color{1,1,1};
    std::string mesh = "cube";      // "cube" | "quad"
    std::string texture;            // nama file di assets/textures/, kosong = polos

    bool dynamic = false;           // true = kena gravitasi & bergerak
    bool solid = true;              // true = ikut dicek tabrakan (AABB)
    Vec3 velocity{0,0,0};
};
struct Scene {
    Camera camera;
    Light light;
    std::vector<Entity> entities;

    // Diisi renderer tiap frame, dipakai logic (mis. picking editor).
    int screenW = 1080, screenH = 1920;

    // Status editor, bukan bagian "dunia" game (tidak disimpan ke scene file).
    bool editMode = false;
    int selectedEntity = -1;
};

inline int findByName(const Scene& s, const std::string& name) {
    for (size_t i = 0; i < s.entities.size(); i++)
        if (s.entities[i].name == name) return (int)i;
    return -1;
}
}
