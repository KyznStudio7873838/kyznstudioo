#pragma once
#include <vector>
#include <string>
#include "Math.h"
namespace kyzn {
struct Transform { Vec3 pos{0,0,0}; Vec3 scale{1,1,1}; float rotZ=0; float rotY=0; };
enum class CameraMode { Ortho2D, Perspective3D };
struct Camera {
    CameraMode mode = CameraMode::Ortho2D;
    Vec3 pos{0,0,3};
    float fov=60, nearZ=0.1f, farZ=100, orthoHeight=10;
};
struct Light {
    Vec3 direction{-0.4f, -1.0f, -0.3f};
    Vec3 color{1, 1, 1};
    float intensity = 1.0f;
    float ambient = 0.25f;
};
struct Entity {
    std::string name;
    Transform t;
    Vec3 color{1,1,1};
    std::string mesh = "cube";
    std::string texture;
    bool dynamic = false;
    bool solid = true;
    Vec3 velocity{0,0,0};
};

// Perintah gambar UI 2D, dalam koordinat piksel layar (0,0)=kiri-atas.
// Diisi ulang oleh Game tiap frame di onUpdate(); Renderer hanya menggambar apa adanya (generik).
struct UIRect { float x,y,w,h; Vec3 color; };
struct UIText { std::string text; float x,y,scale; Vec3 color; };

struct Scene {
    Camera camera;
    Light light;
    std::vector<Entity> entities;

    int screenW = 1080, screenH = 1920; // diisi renderer tiap frame

    // Status editor/UI (transient, tidak ikut disimpan ke scene file).
    bool editMode = false;
    int selectedEntity = -1;
    int activeTab = 0; // 0=Scene 1=Hierarchy 2=Inspector 3=Build

    std::vector<UIRect> uiRects;
    std::vector<UIText> uiTexts;
};

inline int findByName(const Scene& s, const std::string& name) {
    for (size_t i = 0; i < s.entities.size(); i++)
        if (s.entities[i].name == name) return (int)i;
    return -1;
}
}
