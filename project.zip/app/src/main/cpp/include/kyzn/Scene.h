#pragma once
#include <vector>
#include "Math.h"
namespace kyzn {
struct Transform { Vec3 pos{0,0,0}; Vec3 scale{1,1,1}; float rotZ=0; };
enum class CameraMode { Ortho2D, Perspective3D };
struct Camera {
    CameraMode mode = CameraMode::Ortho2D;
    Vec3 pos{0,0,3};
    float fov=60, nearZ=0.1f, farZ=100, orthoHeight=10;
};
struct Entity { Transform t; Vec3 color{1,1,1}; };
struct Scene { Camera camera; std::vector<Entity> entities; };
}
