using UnityEngine;

/// <summary>
/// Player movement, jump, and basic interaction controller for Kyzn Game Studio.
/// Designed for mobile (touch + virtual joystick support ready).
/// </summary>
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float jumpForce = 7f;
    [SerializeField] private float rotationSpeed = 10f;

    [Header("Ground Check")]
    [SerializeField] private Transform groundCheck;
    [SerializeField] private float groundDistance = 0.3f;
    [SerializeField] private LayerMask groundMask;

    private Rigidbody rb;
    private bool isGrounded;
    private Vector3 moveDirection;
    private Camera playerCamera;

    // Mobile input support
    private Vector2 mobileInput;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        playerCamera = Camera.main;

        // Ensure we have required components
        if (rb == null)
            rb = gameObject.AddComponent<Rigidbody>();
    }

    void Update()
    {
        // Ground check
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);

        // Desktop input (fallback)
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        // Prefer mobile input if available
        if (mobileInput.magnitude > 0.1f)
        {
            horizontal = mobileInput.x;
            vertical = mobileInput.y;
        }

        // Camera-relative movement
        Vector3 camForward = playerCamera.transform.forward;
        Vector3 camRight = playerCamera.transform.right;
        camForward.y = 0f;
        camRight.y = 0f;
        camForward.Normalize();
        camRight.Normalize();

        moveDirection = (camForward * vertical + camRight * horizontal).normalized;

        // Jump
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            Jump();
        }

        // Interaction (E key / mobile button)
        if (Input.GetKeyDown(KeyCode.E) || Input.GetButtonDown("Interact"))
        {
            TryInteract();
        }
    }

    void FixedUpdate()
    {
        // Apply movement
        Vector3 targetVelocity = moveDirection * moveSpeed;
        rb.velocity = new Vector3(targetVelocity.x, rb.velocity.y, targetVelocity.z);

        // Rotate towards movement direction
        if (moveDirection.magnitude > 0.1f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(moveDirection);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.fixedDeltaTime);
        }
    }

    public void Jump()
    {
        if (!isGrounded) return;
        rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        isGrounded = false;
    }

    public void SetMobileInput(Vector2 input)
    {
        mobileInput = input;
    }

    private void TryInteract()
    {
        // Simple raycast interaction
        Ray ray = new Ray(transform.position + Vector3.up * 1.2f, transform.forward);
        if (Physics.Raycast(ray, out RaycastHit hit, 2.5f))
        {
            var interactable = hit.collider.GetComponent<IInteractable>();
            interactable?.Interact(this);
        }
    }

    public bool IsGrounded => isGrounded;
}

public interface IInteractable
{
    void Interact(PlayerController player);
}
