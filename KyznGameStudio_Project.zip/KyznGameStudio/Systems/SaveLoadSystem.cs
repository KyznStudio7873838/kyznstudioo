using System;
using System.IO;
using UnityEngine;

/// <summary>
/// Centralized Save / Load system for Kyzn Game Studio.
/// Uses JSON for readability + easy debugging.
/// Supports multiple slots and auto-save.
/// </summary>
public class SaveLoadSystem : MonoBehaviour
{
    public static SaveLoadSystem Instance { get; private set; }

    [Header("Settings")]
    [SerializeField] private string saveFolderName = "KyznSaves";
    [SerializeField] private int maxSlots = 5;
    [SerializeField] private bool autoSaveEnabled = true;
    [SerializeField] private float autoSaveInterval = 120f; // seconds

    private string SavePath => Path.Combine(Application.persistentDataPath, saveFolderName);
    private float autoSaveTimer;

    public event Action<int> OnGameSaved;
    public event Action<int> OnGameLoaded;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        if (!Directory.Exists(SavePath))
            Directory.CreateDirectory(SavePath);
    }

    void Update()
    {
        if (!autoSaveEnabled) return;

        autoSaveTimer += Time.deltaTime;
        if (autoSaveTimer >= autoSaveInterval)
        {
            autoSaveTimer = 0f;
            SaveGame(0); // Slot 0 = auto-save
        }
    }

    public void SaveGame(int slot)
    {
        if (slot < 0 || slot >= maxSlots) return;

        var data = new GameSaveData
        {
            version = Application.version,
            timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
            playerPosition = FindObjectOfType<PlayerController>()?.transform.position ?? Vector3.zero,
            inventoryJson = FindObjectOfType<InventorySystem>()?.ToJson(),
            questJson = QuestManager.Instance?.ToJson(),
            economyJson = EconomySystem.Instance?.ToJson()
        };

        string json = JsonUtility.ToJson(data, true);
        string filePath = Path.Combine(SavePath, $"save_slot_{slot}.json");

        try
        {
            File.WriteAllText(filePath, json);
            OnGameSaved?.Invoke(slot);
            Debug.Log($"[Save] Game saved to slot {slot}");
        }
        catch (Exception e)
        {
            Debug.LogError($"[Save] Failed: {e.Message}");
        }
    }

    public bool LoadGame(int slot)
    {
        string filePath = Path.Combine(SavePath, $"save_slot_{slot}.json");
        if (!File.Exists(filePath))
        {
            Debug.LogWarning($"[Load] Slot {slot} does not exist");
            return false;
        }

        try
        {
            string json = File.ReadAllText(filePath);
            var data = JsonUtility.FromJson<GameSaveData>(json);

            // Apply data
            var player = FindObjectOfType<PlayerController>();
            if (player != null)
                player.transform.position = data.playerPosition;

            FindObjectOfType<InventorySystem>()?.FromJson(data.inventoryJson);
            QuestManager.Instance?.FromJson(data.questJson);
            EconomySystem.Instance?.FromJson(data.economyJson);

            OnGameLoaded?.Invoke(slot);
            Debug.Log($"[Load] Game loaded from slot {slot} ({data.timestamp})");
            return true;
        }
        catch (Exception e)
        {
            Debug.LogError($"[Load] Failed: {e.Message}");
            return false;
        }
    }

    public bool DoesSlotExist(int slot)
    {
        return File.Exists(Path.Combine(SavePath, $"save_slot_{slot}.json"));
    }

    public void DeleteSlot(int slot)
    {
        string filePath = Path.Combine(SavePath, $"save_slot_{slot}.json");
        if (File.Exists(filePath))
            File.Delete(filePath);
    }

    [System.Serializable]
    private class GameSaveData
    {
        public string version;
        public string timestamp;
        public Vector3 playerPosition;
        public string inventoryJson;
        public string questJson;
        public string economyJson;
    }
}
