using System;
using UnityEngine;

/// <summary>
/// Simple but extensible economy / currency system.
/// Supports multiple currencies if needed later.
/// </summary>
public class EconomySystem : MonoBehaviour
{
    public static EconomySystem Instance { get; private set; }

    [Header("Currency")]
    [SerializeField] private int startingGold = 100;
    [SerializeField] private string currencyName = "Gold";

    private int currentGold;

    public event Action<int> OnGoldChanged;
    public event Action<int, int> OnTransaction; // amount, newBalance

    public int Gold => currentGold;
    public string CurrencyName => currencyName;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        currentGold = startingGold;
    }

    public bool AddCurrency(int amount)
    {
        if (amount <= 0) return false;
        currentGold += amount;
        OnGoldChanged?.Invoke(currentGold);
        OnTransaction?.Invoke(amount, currentGold);
        return true;
    }

    public bool SpendCurrency(int amount)
    {
        if (amount <= 0 || currentGold < amount) return false;
        currentGold -= amount;
        OnGoldChanged?.Invoke(currentGold);
        OnTransaction?.Invoke(-amount, currentGold);
        return true;
    }

    public bool CanAfford(int amount) => currentGold >= amount;

    // Shop helper
    public bool BuyItem(string itemId, int price, InventorySystem inventory, ItemData itemData)
    {
        if (!CanAfford(price)) return false;
        if (!inventory.HasSpace) return false;

        if (SpendCurrency(price))
        {
            inventory.AddItem(itemData, 1);
            return true;
        }
        return false;
    }

    // Save / Load
    public string ToJson()
    {
        return JsonUtility.ToJson(new EconomySave { gold = currentGold });
    }

    public void FromJson(string json)
    {
        var data = JsonUtility.FromJson<EconomySave>(json);
        currentGold = data.gold;
        OnGoldChanged?.Invoke(currentGold);
    }

    [System.Serializable]
    private class EconomySave
    {
        public int gold;
    }
}
