using UnityEngine;
using UnityEngine.AI;

/// <summary>
/// Basic NPC with patrol, dialogue trigger, and quest giver support.
/// Uses NavMesh for movement.
/// </summary>
public class NPCController : MonoBehaviour, IInteractable
{
    [Header("Identity")]
    public string npcName = "Villager";
    public string dialogueId; // Reference to dialogue system

    [Header("Behavior")]
    public NPCState currentState = NPCState.Idle;
    public Transform[] patrolPoints;
    public float patrolSpeed = 2f;
    public float waitTimeAtPoint = 2f;

    [Header("Quest")]
    public string questToGiveId;
    public bool isQuestGiver;

    private NavMeshAgent agent;
    private int currentPatrolIndex;
    private float waitTimer;
    private Animator animator;

    public enum NPCState { Idle, Patrol, Talk, Combat }

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();

        if (agent != null)
            agent.speed = patrolSpeed;

        if (patrolPoints != null && patrolPoints.Length > 0)
            currentState = NPCState.Patrol;
    }

    void Update()
    {
        switch (currentState)
        {
            case NPCState.Patrol:
                HandlePatrol();
                break;
            case NPCState.Talk:
                // Face player, stop moving
                if (agent != null) agent.isStopped = true;
                break;
            case NPCState.Idle:
            default:
                if (agent != null) agent.isStopped = true;
                break;
        }

        // Simple animator
        if (animator != null && agent != null)
        {
            animator.SetFloat("Speed", agent.velocity.magnitude);
        }
    }

    private void HandlePatrol()
    {
        if (patrolPoints == null || patrolPoints.Length == 0) return;

        if (agent.remainingDistance < 0.5f)
        {
            waitTimer += Time.deltaTime;
            if (waitTimer >= waitTimeAtPoint)
            {
                waitTimer = 0f;
                currentPatrolIndex = (currentPatrolIndex + 1) % patrolPoints.Length;
                agent.SetDestination(patrolPoints[currentPatrolIndex].position);
            }
        }
    }

    public void Interact(PlayerController player)
    {
        currentState = NPCState.Talk;

        // Trigger dialogue (placeholder)
        Debug.Log($"[{npcName}] Hello, traveler!");

        // Offer quest if available
        if (isQuestGiver && !string.IsNullOrEmpty(questToGiveId))
        {
            // QuestManager.Instance.StartQuest(...);
            Debug.Log($"[{npcName}] I have a quest for you: {questToGiveId}");
        }
    }

    public void EndInteraction()
    {
        currentState = NPCState.Patrol;
        if (agent != null) agent.isStopped = false;
    }
}
