using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Quest system supporting main/side quests, objectives, rewards, and progress tracking.
/// Designed for easy UI binding and save/load.
/// </summary>
[System.Serializable]
public class QuestObjective
{
    public string id;
    public string description;
    public int requiredAmount = 1;
    public int currentAmount;
    public bool isCompleted => currentAmount >= requiredAmount;

    public void Progress(int amount = 1)
    {
        currentAmount = Mathf.Min(currentAmount + amount, requiredAmount);
    }
}

[System.Serializable]
public class QuestReward
{
    public string itemId;
    public int amount;
    public int currencyAmount; // uang / gold
    public int experience;
}

[System.Serializable]
public class Quest
{
    public string id;
    public string title;
    public string description;
    public QuestType type = QuestType.Side;
    public List<QuestObjective> objectives = new List<QuestObjective>();
    public List<QuestReward> rewards = new List<QuestReward>();
    public bool isActive;
    public bool isCompleted;
    public bool isFailed;

    public enum QuestType { Main, Side, Daily, Hidden }

    public bool AreAllObjectivesComplete()
    {
        foreach (var obj in objectives)
            if (!obj.isCompleted) return false;
        return true;
    }
}

public class QuestManager : MonoBehaviour
{
    public static QuestManager Instance { get; private set; }

    [Header("Active Quests")]
    public List<Quest> activeQuests = new List<Quest>();
    public List<Quest> completedQuests = new List<Quest>();

    // Events
    public event Action<Quest> OnQuestStarted;
    public event Action<Quest> OnQuestCompleted;
    public event Action<Quest, QuestObjective> OnObjectiveProgressed;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void StartQuest(Quest quest)
    {
        if (quest == null || quest.isActive || quest.isCompleted) return;

        quest.isActive = true;
        activeQuests.Add(quest);
        OnQuestStarted?.Invoke(quest);

        Debug.Log($"[Quest] Started: {quest.title}");
    }

    public void ProgressObjective(string questId, string objectiveId, int amount = 1)
    {
        var quest = activeQuests.Find(q => q.id == questId);
        if (quest == null) return;

        var objective = quest.objectives.Find(o => o.id == objectiveId);
        if (objective == null || objective.isCompleted) return;

        objective.Progress(amount);
        OnObjectiveProgressed?.Invoke(quest, objective);

        if (quest.AreAllObjectivesComplete())
        {
            CompleteQuest(quest);
        }
    }

    public void CompleteQuest(Quest quest)
    {
        if (quest == null || !quest.isActive) return;

        quest.isActive = false;
        quest.isCompleted = true;
        activeQuests.Remove(quest);
        completedQuests.Add(quest);

        // Give rewards
        GiveRewards(quest);

        OnQuestCompleted?.Invoke(quest);
        Debug.Log($"[Quest] Completed: {quest.title}");
    }

    private void GiveRewards(Quest quest)
    {
        var inventory = FindObjectOfType<InventorySystem>();
        var economy = FindObjectOfType<EconomySystem>();

        foreach (var reward in quest.rewards)
        {
            if (reward.currencyAmount > 0 && economy != null)
            {
                economy.AddCurrency(reward.currencyAmount);
            }

            // Item rewards would require ItemDatabase lookup
            // inventory?.AddItem(ItemDatabase.Get(reward.itemId), reward.amount);
        }
    }

    public Quest GetActiveQuest(string id) => activeQuests.Find(q => q.id == id);

    public bool HasActiveQuest(string id) => activeQuests.Exists(q => q.id == id);

    // Save / Load
    public string ToJson()
    {
        var data = new QuestSaveData
        {
            active = activeQuests,
            completed = completedQuests
        };
        return JsonUtility.ToJson(data);
    }

    public void FromJson(string json)
    {
        var data = JsonUtility.FromJson<QuestSaveData>(json);
        activeQuests = data.active ?? new List<Quest>();
        completedQuests = data.completed ?? new List<Quest>();
    }

    [System.Serializable]
    private class QuestSaveData
    {
        public List<Quest> active;
        public List<Quest> completed;
    }
}
