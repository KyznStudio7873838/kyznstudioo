using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Full inventory system with stackable items, weight limit, and events.
/// Supports save/load via JSON serialization.
/// </summary>
[System.Serializable]
public class ItemData
{
    public string id;
    public string displayName;
    public string description;
    public int maxStack = 99;
    public float weight = 0.1f;
    public Sprite icon;
    public ItemType type;

    public enum ItemType { Consumable, Equipment, Quest, Material, Currency }
}

[System.Serializable]
public class InventorySlot
{
    public ItemData item;
    public int quantity;

    public bool IsEmpty => item == null || quantity <= 0;
}

public class InventorySystem : MonoBehaviour
{
    [Header("Settings")]
    [SerializeField] private int maxSlots = 30;
    [SerializeField] private float maxWeight = 50f;

    [Header("Runtime")]
    public List<InventorySlot> slots = new List<InventorySlot>();

    // Events for UI binding
    public event Action OnInventoryChanged;
    public event Action<ItemData, int> OnItemAdded;
    public event Action<ItemData, int> OnItemRemoved;

    private float currentWeight;

    void Awake()
    {
        // Initialize empty slots
        for (int i = 0; i < maxSlots; i++)
        {
            slots.Add(new InventorySlot());
        }
    }

    public bool AddItem(ItemData item, int amount = 1)
    {
        if (item == null || amount <= 0) return false;

        float addedWeight = item.weight * amount;
        if (currentWeight + addedWeight > maxWeight)
        {
            Debug.LogWarning("[Inventory] Weight limit exceeded!");
            return false;
        }

        // Try stack first
        for (int i = 0; i < slots.Count; i++)
        {
            if (!slots[i].IsEmpty && slots[i].item.id == item.id && slots[i].quantity < item.maxStack)
            {
                int canAdd = Mathf.Min(amount, item.maxStack - slots[i].quantity);
                slots[i].quantity += canAdd;
                amount -= canAdd;
                currentWeight += item.weight * canAdd;

                if (amount <= 0)
                {
                    OnItemAdded?.Invoke(item, canAdd);
                    OnInventoryChanged?.Invoke();
                    return true;
                }
            }
        }

        // Find empty slots
        while (amount > 0)
        {
            int emptyIndex = slots.FindIndex(s => s.IsEmpty);
            if (emptyIndex < 0)
            {
                Debug.LogWarning("[Inventory] No empty slots!");
                return false;
            }

            int toAdd = Mathf.Min(amount, item.maxStack);
            slots[emptyIndex].item = item;
            slots[emptyIndex].quantity = toAdd;
            currentWeight += item.weight * toAdd;
            amount -= toAdd;

            OnItemAdded?.Invoke(item, toAdd);
        }

        OnInventoryChanged?.Invoke();
        return true;
    }

    public bool RemoveItem(string itemId, int amount = 1)
    {
        int remaining = amount;

        for (int i = 0; i < slots.Count && remaining > 0; i++)
        {
            if (!slots[i].IsEmpty && slots[i].item.id == itemId)
            {
                int remove = Mathf.Min(remaining, slots[i].quantity);
                slots[i].quantity -= remove;
                currentWeight -= slots[i].item.weight * remove;
                remaining -= remove;

                OnItemRemoved?.Invoke(slots[i].item, remove);

                if (slots[i].quantity <= 0)
                {
                    slots[i].item = null;
                    slots[i].quantity = 0;
                }
            }
        }

        if (remaining < amount)
        {
            OnInventoryChanged?.Invoke();
            return true;
        }
        return false;
    }

    public int GetItemCount(string itemId)
    {
        int total = 0;
        foreach (var slot in slots)
        {
            if (!slot.IsEmpty && slot.item.id == itemId)
                total += slot.quantity;
        }
        return total;
    }

    public float CurrentWeight => currentWeight;
    public float MaxWeight => maxWeight;
    public bool HasSpace => slots.Exists(s => s.IsEmpty);

    // Save / Load helpers
    public string ToJson()
    {
        return JsonUtility.ToJson(this);
    }

    public void FromJson(string json)
    {
        JsonUtility.FromJsonOverwrite(json, this);
        OnInventoryChanged?.Invoke();
    }
}
